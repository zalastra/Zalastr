## Logo integration — 2026-10-28 (aapki bheji hui image, koi naya logo nahi banaya)
- logo.png (512x512) — header me top-left, NOVA TRANSFER text ke saath. Logo me sirf "Nova transfer" likha hai, isme "v2" nahi likha hai. v2 sirf is project version ka naam hai, logo ka text nahi.
- favicon.png (192x192) — browser tab ka favicon, aur apple-touch-icon ke liye logo.png use hota hai.
- Dono files aapki bheji hui PNG se hi banayi gayi hain, sirf size chhota kiya gaya hai taaki page slow na ho. Original 1254x1254, 1.5MB thi; header wali 512px aur favicon wali 192px hai.
- Files (zip me ye 6 files root par honi chahiye): index.html, styles.css, app.js, logo.png, favicon.png, README-DEPLOY.md
# NOVA TRANSFER v2.2 — Deployment guide, changed files, test results

## Ye project kya hai, aur kya nahi hai
- Ye v2 STATIC website hai: index.html + styles.css + app.js. Koi Node server nahi, koi Express nahi, koi /api nahi, koi database nahi.
- File bytes server par save nahi hote. Sender se receiver tak sidha WebRTC (PeerJS) se jate hain. PeerJS cloud sirf dono device ko milane ke liye signalling karta hai.
- Isliye isko Cloudflare **Pages** par upload karo, **Workers** par nahi. Workers me iska koi entry point nahi hai.
- Purani v1 (~/workspace/nova-transfer/, Node + Express + WebSocket, package.json me express, ws, qrcode, bwip-js) Workers par isliye nahi chali thi, kyunki Workers Node server, local filesystem aur in-memory session storage nahi chalata. v1 ko Workers par chalane ke liye poora rewrite chahiye hota, R2 + Durable Objects ke saath — wo is v2.2 me implement NAHI kiya gaya hai, kyunki aapka chalta hua UI aur 6-digit P2P workflow hi preserve karna tha.

## Files (zip me ye 4 files root par honi chahiye)
- index.html
- styles.css
- app.js
- README-DEPLOY.md (ye file)

Backup: ~/workspace/nova-transfer-v2-backup-2026-10-28-master/ me v2.2 se pehle wali copy safe hai. UI, layout, colours, animations, branding me koi redesign nahi kiya gaya hai.

## Changed files — v2.2 (minimal, sirf bug fix)
1. index.html — SIRF QR script badla: galat `qrcode@1.5.4/build/qrcode.min.js` (404) hatake verified `qrcodejs@1.0.0/qrcode.min.js` lagaya. Canvas ki jagah `<div id="qrBox">` + fallback `<img id="qrImg">` + QR link text + Copy receive link button. Baaki HTML, layout, text, tabs bilkul same.
2. styles.css — SIRF `#qrBox` aur `#qrImg` ke liye wahi white background, padding, radius style add kiya jo pehle canvas ka tha. Baaki CSS, blobs, animations, buttons same.
3. app.js — SIRF ye changes:
   - showCode(): QRCodeJS se QR banao, fail ho to qrserver image fallback, fail ho to bhi code + copyable link kaam karega. QR me sirf receiver URL + 6-digit code hai, koi secret, key ya token nahi.
   - Speed: chunk 16KB rakha (safe WebRTC size). Buffer high-water 256KB se 4MB, low-water 1MB, `bufferedamountlow` event se resume (50ms poll ki jagah), har chunk par delay hatake har 32 chunk par yield. Live MB/s sender aur receiver dono par dikhta hai.
   - v2.1 ke fixes barkarar: Blob/ArrayBuffer/Uint8Array chunks, download/preview sirf tab jab received bytes = file size, image preview, playable video preview, PDF open link.
   - Koi Base64 conversion nahi hai, koi poori file JSON me nahi jati, file slice karke 16KB binary chunks me jati hai.

## Cloudflare Pages par deploy, ek ek karke
1. Cloudflare Dashboard kholo.
2. Workers & Pages par jao.
3. Pages par jao.
4. Create application par click karo.
5. Upload assets par click karo.
6. Project ka naam do, jaise nova-transfer-v2.
7. Zip ko extract karke wo folder select karo, jisme index.html root par ho. Folder ke andar folder mat banao.
8. Deploy site par click karo.
9. Deploy hone ke baad jo link mile, usko kholo.
10. Send tab me file select karo.
11. Generate Transfer Code par click karo.
12. QR scan karo ya code copy karo, dusre device par Receive me code dalo.
13. Dusre device par Accept dabao, phir Download dabao.

## Environment variables aur bindings — koi nahi chahiye
- Env vars: koi nahi.
- Workers bindings: koi nahi. R2, Durable Objects, KV: is v2.2 me use nahi hote, isliye configure karne ki zaroorat nahi.
- Agar aap baad me server-mediated storage chahte ho (file server par save ho, sender offline ho tab bhi download ho), to uske liye alag kaam chahiye hoga: R2 bucket + presigned URL + Durable Object session + server-side code validation. Wo is delivery me claim nahi kiya gaya hai, kyunki uske liye aapka R2 account/binding abhi confirm nahi hai.

## Security — imaandaar limit
- 6-digit code is design me session identifier hai, server-side validation is static app me possible nahi hai, kyunki koi server nahi hai. Mitigation jo hai: file tabhi bhejti hai jab receiver Accept dabata hai, file kahin save nahi hoti, sender page band karte hi session khatam ho jata hai, aur QR me koi secret nahi hota.
- Koi password, OTP, bank PIN, Aadhaar/PAN kabhi mat mango, transfer ke naam par jo ye mange wo scam hai.
- Code ko sirf usi receiver ke saath share karo jisko file bhejni hai, kyunki code jiske paas hoga wo connect karke Accept kar sakta hai.

## Test results — jo actually check kiya gaya hai
- PASS: JavaScript syntax — `node --check app.js` OK.
- PASS: Local homepage — python http server par index 200 (5892 bytes), app.js 200 (16847 bytes), styles.css 200 (5127 bytes).
- PASS: QR library CDN — qrcodejs@1.0.0 = 200, PeerJS 1.5.4 = 200.
- FAIL (root cause, ab fixed): purana qrcode@1.5.4/build/qrcode.min.js = 404, isliye QR kabhi draw hi nahi hota tha. Yehi QR error tha.
- NOT YET TESTED LIVE BY ASSISTANT: do alag real device par poori file ka end-to-end transfer aur hash match. Ye test assistant ke VM browser se honestly claim nahi kiya ja raha hai, kyunki do real device (phone + PC) ka test aapko karna hoga. Test order: chhoti photo, phir PDF, phir video. Sender par MB/s aur File delivered, receiver par 100% aur Download + preview check karo.

## Limitations — speed ke baare me sach
- P2P speed aapke dono device ke internet, network route aur browser par depend karti hai, koi server speed guarantee nahi de sakta. v2.2 ne browser buffer stall hataya hai, isliye pehle se tez honi chahiye, lekin koi fixed MB/s number claim nahi kiya ja raha hai, kyunki wo network par depend karta hai.
- Dono device ek saath online hone chahiye, sender page transfer khatam hone tak khula rehna chahiye. Sender band karega to transfer ruk jayega.
- Agar code galat ho ya sender online na ho, to receiver ko "Code not found" dikhega. Tab code dobara check karo aur sender page khula rakho.
