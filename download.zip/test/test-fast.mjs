// Local end-to-end test: 30.4 MB file, binary PUT direct, binary GET direct,
// SHA-256 compare, Range 206 check, speed measure. No Base64, no Worker bytes.
import fs from 'node:fs';
import crypto from 'node:crypto';
const API = 'http://localhost:8787';
const SIZE = Math.round(30.4 * 1024 * 1024);
const testFile = '/tmp/nova-test-30mb.bin';
if (!fs.existsSync(testFile) || fs.statSync(testFile).size !== SIZE) {
  const buf = crypto.randomBytes(SIZE); fs.writeFileSync(testFile, buf); console.log('Generated test file', SIZE);
}
const origHash = crypto.createHash('sha256').update(fs.readFileSync(testFile)).digest('hex');
console.log('Original SHA-256', origHash);
const created = await (await fetch(API + '/session/create', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ device: 'test', files: [{ name: 'test-30mb.bin', size: SIZE, type: 'application/octet-stream' }] }) })).json();
console.log('Code', created.code);
const t0 = Date.now();
const put = await fetch(created.uploads[0].url, { method: 'PUT', headers: { 'Content-Type': 'application/octet-stream' }, body: fs.readFileSync(testFile) });
console.log('Upload status', put.status, 'in', ((Date.now() - t0) / 1000).toFixed(2), 's');
await fetch(API + '/session/complete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: created.code, files: [{ sha256: origHash }] }) });
const lookup = await (await fetch(API + '/session/lookup', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: created.code }) })).json();
console.log('Lookup files', lookup.files.map(f => [f.name, f.size, f.sha256 === origHash]));
const dl = await (await fetch(API + '/session/download', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: created.code, index: 0 }) })).json();
console.log('Direct download URL (Worker NOT in path):', dl.url);
const rangeRes = await fetch(dl.url, { headers: { Range: 'bytes=0-1023' } });
console.log('Range test status (expect 206):', rangeRes.status, 'Content-Range:', rangeRes.headers.get('content-range'));
const t1 = Date.now();
const down = await fetch(dl.url);
const downBuf = Buffer.from(await down.arrayBuffer());
const downTime = (Date.now() - t1) / 1000;
const downHash = crypto.createHash('sha256').update(downBuf).digest('hex');
console.log('Downloaded bytes', downBuf.length, 'in', downTime.toFixed(2), 's =', (downBuf.length / 1024 / 1024 / downTime).toFixed(2), 'MB/s (LOCAL LOOPBACK, NOT LIVE NETWORK)');
console.log('Download SHA-256', downHash);
console.log('SHA-256 MATCH:', downHash === origHash ? 'YES' : 'NO');
if (downHash !== origHash) process.exit(1);
