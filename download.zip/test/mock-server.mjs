// Mock for the Worker + R2, LOCAL TEST ONLY. Same API shape as worker/index.js,
// but storage is a local folder and "presigned" URLs point directly to that folder.
// The Worker is never in the download path in either version — that is the point.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
const PORT = 8787;
const STORE = '/tmp/nova-mock-store';
fs.mkdirSync(STORE, { recursive: true });
const sessions = new Map();
function send(res, code, obj) { res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }); res.end(JSON.stringify(obj)); }
function readBody(req) { return new Promise(r => { let d = ''; req.on('data', c => d += c); req.on('end', () => r(d ? JSON.parse(d) : {})); }); }
const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') { res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST, GET, PUT', 'Access-Control-Allow-Headers': 'Content-Type' }); return res.end(); }
  const u = new URL(req.url, 'http://localhost');
  if (u.pathname === '/health') return send(res, 200, { ok: true });
  if (u.pathname.startsWith('/files/')) {
    const file = path.join(STORE, u.pathname.slice(7));
    if (!fs.existsSync(file)) { res.writeHead(404); return res.end(); }
    const stat = fs.statSync(file);
    const range = req.headers.range;
    if (range) {
      const m = /bytes=(\d+)-(\d*)/.exec(range);
      const start = Number(m[1]); const end = m[2] ? Number(m[2]) : stat.size - 1;
      res.writeHead(206, { 'Content-Range': `bytes ${start}-${end}/${stat.size}`, 'Accept-Ranges': 'bytes', 'Content-Length': end - start + 1, 'Content-Type': 'application/octet-stream' });
      return fs.createReadStream(file, { start, end }).pipe(res);
    }
    res.writeHead(200, { 'Accept-Ranges': 'bytes', 'Content-Length': stat.size, 'Content-Type': 'application/octet-stream' });
    return fs.createReadStream(file).pipe(res);
  }
  if (req.method === 'PUT' && u.pathname.startsWith('/upload/')) {
    const file = path.join(STORE, u.pathname.slice(8)); fs.mkdirSync(path.dirname(file), { recursive: true });
    const ws = fs.createWriteStream(file); req.pipe(ws); ws.on('finish', () => { res.writeHead(200); res.end(); }); return;
  }
  if (req.method !== 'POST') return send(res, 405, { error: 'Method not allowed' });
  const body = await readBody(req);
  if (u.pathname === '/session/create') {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    const uploads = body.files.map((f, i) => ({ url: `http://localhost:${PORT}/upload/${code}-${i}` }));
    sessions.set(code, { code, files: body.files.map((f, i) => ({ ...f, key: `${code}-${i}` })), ready: false, expiresAt: Date.now() + 3600000 });
    return send(res, 200, { code, uploads, expiresAt: Date.now() + 3600000 });
  }
  if (u.pathname === '/session/complete') {
    const s = sessions.get(String(body.code)); if (!s) return send(res, 404, { error: 'not found' });
    s.ready = true; s.files = s.files.map((f, i) => ({ ...f, sha256: body.files[i]?.sha256 || null }));
    return send(res, 200, { ok: true });
  }
  if (u.pathname === '/session/lookup') {
    const s = sessions.get(String(body.code)); if (!s) return send(res, 404, { error: 'not found' }); if (!s.ready) return send(res, 409, { error: 'not ready' });
    return send(res, 200, { code: s.code, files: s.files });
  }
  if (u.pathname === '/session/download') {
    const s = sessions.get(String(body.code)); if (!s) return send(res, 404, { error: 'not found' });
    return send(res, 200, { url: `http://localhost:${PORT}/files/${s.files[body.index].key}`, name: s.files[body.index].name, size: s.files[body.index].size });
  }
  if (u.pathname === '/session/delete') { sessions.delete(String(body.code)); return send(res, 200, { ok: true }); }
  return send(res, 404, { error: 'not found' });
});
server.listen(PORT, () => console.log('Mock R2+Worker on', PORT));
