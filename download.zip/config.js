// NOVA TRANSFER v3-fast — config. Fill ONLY the Worker URL after you deploy it.
// Leave empty ('') and the site keeps working in the old P2P mode only.
// NEVER put R2 keys, secrets, or tokens in this file. The Worker holds them.
// Example after deploy: window.NOVA_FAST_API = 'https://nvt-api.YOURNAME.workers.dev';
window.NOVA_FAST_API = '';
