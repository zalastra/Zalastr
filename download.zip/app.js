// NOVA TRANSFER v3.1-diag — UI unchanged in appearance. Two diagnostic/correction changes:
// CORRECTION to v3: reliable:false is REVERTED to PeerJS default (reliable:true).
// File transfer must be reliable; an unreliable channel with no app-level
// retransmission could lose chunks and corrupt files. Do not trade integrity for speed.
// ICE: PeerJS 1.5 by default uses STUN only (stun.l.google.com), NO TURN.
// Adding more STUN servers does NOT increase throughput — STUN only discovers
// your public address for NAT traversal. Throughput is set by the direct path,
// sender upload, receiver download, and congestion, not by STUN count.
// No TURN is added here on purpose: a free/shared TURN relay adds a single
// server bottleneck, extra latency, and per-GB cost if paid, and is the
// classic cause of 0.07-0.16 MB/s. If direct P2P fails, use Fast R2 mode,
// do not silently fall back to a slow relay.
// DIAGNOSTICS: RTCPeerConnection.getStats() is polled every 1s during P2P
// transfer and shown on screen: route (Direct vs Relay), RTT, packet loss,
// and channel throughput (bytesSent/bytesReceived), separate from app MB/s.
// Sender speed and receiver speed are therefore measured separately.
// No Base64 anywhere. File bytes are binary ArrayBuffer/Blob in P2P,
// and binary PUT/GET in Fast mode. No file is copied through Worker/InfinityFree.
const $ = (s) => document.querySelector(s);
const fmt = (n) => n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB';
const FAST_API = (window.NOVA_FAST_API || '').replace(/\/$/, '');
const CHUNK = 65536; // 64KB P2P chunks (was 16KB in v2.2)
const PEER_CONFIG = { config: { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun.cloudflare.com:3478' }], sdpSemantics: 'unified-plan' } };
// No TURN server in PEER_CONFIG, on purpose. See header comment.
// ---------- getStats diagnostics (P2P only, 1s poll, local only, no signalling) ----------
let statsTimer = null, statsPrev = null;
function stopStats() { if (statsTimer) clearInterval(statsTimer); statsTimer = null; statsPrev = null; }
function startStats(conn, elId, label) {
  stopStats();
  const pc = conn && conn.peerConnection ? conn.peerConnection : null;
  const el = document.getElementById(elId);
  if (!pc || !el) return;
  statsTimer = setInterval(async () => {
    try {
      const stats = await pc.getStats();
      let pair = null, local = null, remote = null;
      stats.forEach(r => { if (r.type === 'candidate-pair' && (r.nominated || r.state === 'succeeded')) pair = r; });
      if (!pair) stats.forEach(r => { if (r.type === 'candidate-pair' && r.state === 'in-progress') pair = r; });
      if (pair) {
        stats.forEach(r => { if (r.id === pair.localCandidateId) local = r; if (r.id === pair.remoteCandidateId) remote = r; });
      }
      const bytes = label === 'upload' ? (pair ? pair.bytesSent : 0) : (pair ? pair.bytesReceived : 0);
      const packets = label === 'upload' ? (pair ? pair.packetsSent : 0) : (pair ? pair.packetsReceived : 0);
      const lost = pair ? (pair.packetsLost || 0) : 0;
      const rtt = pair && pair.currentRoundTripTime != null ? Math.round(pair.currentRoundTripTime * 1000) : null;
      let chanSpeed = null;
      if (statsPrev && statsPrev.bytes != null && bytes != null) chanSpeed = Math.max(0, (bytes - statsPrev.bytes) / 1024 / 1024);
      statsPrev = { bytes };
      const route = (local && local.candidateType === 'relay') || (remote && remote.candidateType === 'relay') ? 'RELAY (TURN) — slow, use Fast mode' : ((local && remote) ? 'DIRECT' : 'Unknown');
      const lossPct = (packets + lost) ? ((lost / (packets + lost)) * 100).toFixed(1) : '0.0';
      el.textContent = `Diag: Route ${route} · RTT ${rtt != null ? rtt + ' ms' : '—'} · Loss ${lossPct}% · Channel ${label} ${chanSpeed != null ? chanSpeed.toFixed(2) + ' MB/s' : '—'}`;
    } catch (e) { /* stats unavailable in this browser — do not fake a number */ }
  }, 1000);
}
const MAX_BUFFERED = 4194304; // 4MB high-water
const LOW_BUFFERED = 1048576; // 1MB low-water
let currentTransferUrl = '';

function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.remove('hidden');
  setTimeout(() => t.classList.add('hidden'), 4000);
}
function saveHistory(item) {
  try {
    const h = JSON.parse(localStorage.getItem('nova_v2_history') || '[]');
    h.unshift({ time: new Date().toLocaleString(), ...item });
    localStorage.setItem('nova_v2_history', JSON.stringify(h.slice(0, 20)));
    renderHistory();
  } catch {}
}
function renderHistory() {
  try {
    const h = JSON.parse(localStorage.getItem('nova_v2_history') || '[]');
    $('#historyList').innerHTML = h.length ? h.map(x => `<div class="fileitem"><span>${x.direction} · ${x.status}</span><span class="muted small">${x.time} · ${x.files || ''}</span></div>`).join('') : '<p class="muted">No history yet.</p>';
  } catch {}
}
renderHistory();

document.querySelectorAll('.tabbtn').forEach(b => {
  b.onclick = () => {
    document.querySelectorAll('.tabbtn').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    ['send', 'receive', 'how'].forEach(t => $('#tab-' + t).classList.toggle('hidden', t !== b.dataset.tab));
  };
});
function showTab(name) { document.querySelector(`.tabbtn[data-tab="${name}"]`).click(); }

// ---------- SENDER ----------
let sendFiles = [], senderPeer = null, senderConn = null, sending = false;
let pendingAck = null;

const dz = $('#dropzone');
dz.onclick = () => $('#fileInput').click();
['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('dragging'); }));
['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('dragging'); }));
dz.addEventListener('drop', e => addFiles(e.dataTransfer.files));
$('#fileInput').onchange = e => addFiles(e.target.files);

function addFiles(list) { for (const f of list) sendFiles.push(f); renderSendFiles(); }
function renderSendFiles() {
  $('#fileList').innerHTML = sendFiles.map((f, i) => `<div class="fileitem"><span>📄 ${f.name}</span><span class="muted small">${fmt(f.size)} · <a href="#" data-i="${i}" style="color:#f87171">Remove</a></span></div>`).join('');
  document.querySelectorAll('#fileList a').forEach(a => a.onclick = (e) => { e.preventDefault(); sendFiles.splice(Number(a.dataset.i), 1); renderSendFiles(); });
  const total = sendFiles.reduce((a, f) => a + f.size, 0);
  $('#fileTotal').textContent = sendFiles.length ? `${sendFiles.length} file(s) · Total ${fmt(total)}` : '';
  $('#generateBtn').disabled = !sendFiles.length || sending;
}
$('#clearBtn').onclick = () => { sendFiles = []; renderSendFiles(); $('#sendStatus').classList.add('hidden'); try { senderPeer && senderPeer.destroy(); } catch {} senderPeer = null; };

function showCode(code) {
  const box = $('#codeBox'); box.innerHTML = '';
  for (const ch of code) { const s = document.createElement('span'); s.textContent = ch; box.appendChild(s); }
  currentTransferUrl = location.href.split('?')[0].split('#')[0] + '?code=' + code + '#receive';
  $('#qrLink').textContent = currentTransferUrl;
  $('#copyLinkBtn').classList.remove('hidden');
  const qrBox = $('#qrBox'); qrBox.innerHTML = '';
  const qrImg = $('#qrImg'); qrImg.classList.add('hidden');
  try {
    if (window.QRCode) {
      new window.QRCode(qrBox, { text: currentTransferUrl, width: 200, height: 200, correctLevel: window.QRCode.CorrectLevel.M });
      $('#qrNote').textContent = 'Scan with phone camera to open Receive with this code filled. If scanning fails, use Copy receive link.';
      return;
    }
    throw new Error('QR library not loaded');
  } catch (e) {
    // Fallback: QR as an image from qrserver. If that also fails, the
    // code and copyable link above still work — QR is never a blocker.
    qrImg.src = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&margin=10&data=' + encodeURIComponent(currentTransferUrl);
    qrImg.classList.remove('hidden');
    qrImg.onerror = () => { qrImg.classList.add('hidden'); $('#qrNote').textContent = 'QR could not load. Use the code above or Copy receive link.'; };
    $('#qrNote').textContent = 'Scan with phone camera to open Receive with this code filled.';
  }
}
$('#copyLinkBtn').onclick = async () => {
  try { await navigator.clipboard.writeText(currentTransferUrl); toast('Receive link copied ✓'); }
  catch { prompt('Copy this link:', currentTransferUrl); }
};

function getDataChannel(conn) {
  // PeerJS DataConnection exposes the raw RTCDataChannel as .dataChannel in v1.5.
  return conn && conn.dataChannel ? conn.dataChannel : null;
}
async function waitForBuffer(conn) {
  const dc = getDataChannel(conn);
  if (!dc) { await new Promise(r => setTimeout(r, 10)); return; }
  try { dc.bufferedAmountLowThreshold = LOW_BUFFERED; } catch {}
  let waited = 0;
  while (dc.bufferedAmount > MAX_BUFFERED && waited < 30000) {
    // Wake as soon as the buffer drains below low-water, not on a 50ms poll.
    await new Promise((resolve) => {
      let done = false;
      const finish = () => { if (!done) { done = true; resolve(); } };
      try { dc.addEventListener('bufferedamountlow', finish, { once: true }); } catch {}
      setTimeout(finish, 20);
    });
    waited += 20;
  }
}
function speedText(bytes, startMs) {
  const sec = Math.max(0.1, (Date.now() - startMs) / 1000);
  return (bytes / 1048576 / sec).toFixed(2) + ' MB/s';
}

// ---------- FAST MODE (R2 direct, Worker only authorises) ----------
async function fastApi(path, body) {
  const r = await fetch(FAST_API + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || ('Fast API error ' + r.status));
  return j;
}
async function sha256Hex(file) {
  if (!window.crypto || !crypto.subtle || file.size > 200 * 1024 * 1024) return null; // skip hash for very large files, size check still applies
  const buf = await file.arrayBuffer();
  const h = await crypto.subtle.digest('SHA-256', buf);
  return Array.from(new Uint8Array(h)).map(b => b.toString(16).padStart(2, '0')).join('');
}
function uploadDirect(url, file, onProgress) {
  // XMLHttpRequest gives real upload progress; fetch does not. Binary body, no Base64, no copy.
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('PUT', url, true);
    xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
    xhr.upload.onprogress = (e) => { if (e.lengthComputable && onProgress) onProgress(e.loaded, e.total); };
    xhr.onload = () => (xhr.status >= 200 && xhr.status < 300) ? resolve() : reject(new Error('Upload failed ' + xhr.status));
    xhr.onerror = () => reject(new Error('Upload network error'));
    xhr.send(file);
  });
}
async function fastSend() {
  const device = ($('#sendDevice').value || '').trim() || 'My device';
  $('#senderState').textContent = 'Fast mode: creating session…';
  const created = await fastApi('/session/create', { device, files: sendFiles.map(f => ({ name: f.name, size: f.size, type: f.type || 'application/octet-stream' })) });
  showCode(created.code);
  $('#senderState').textContent = 'Fast mode: uploading directly to storage (not through this site)…';
  const total = sendFiles.reduce((a, f) => a + f.size, 0);
  let sent = 0; const startMs = Date.now();
  const metas = [];
  for (let i = 0; i < sendFiles.length; i++) {
    const f = sendFiles[i];
    await uploadDirect(created.uploads[i].url, f, (loaded) => {
      const cur = sent + loaded;
      const pct = total ? Math.round(cur / total * 100) : 100;
      $('#sendProgress').style.width = pct + '%';
      $('#sendProgressText').textContent = `Sent ${fmt(cur)} of ${fmt(total)} · ${pct}% · ${speedText(cur, startMs)} · File ${i + 1} of ${sendFiles.length} (direct)`;
    });
    sent += f.size;
    metas.push({ name: f.name, size: f.size, type: f.type || 'application/octet-stream', sha256: await sha256Hex(f) });
  }
  await fastApi('/session/complete', { code: created.code, files: metas });
  $('#senderState').textContent = 'Fast upload complete ✓ Share the code. You can now close this page — receiver downloads from storage, not from you.';
  $('#sendProgress').style.width = '100%';
  toast('Fast upload complete ✓');
  saveHistory({ direction: 'Sent (Fast)', status: 'Completed', files: sendFiles.map(f => f.name).join(', ') });
  sending = false;
}
let fastSession = null;
async function fastReceive(code) {
  const j = await fastApi('/session/lookup', { code });
  fastSession = j;
  recvMeta = j; recvTotal = j.files.reduce((a, f) => a + f.size, 0);
  $('#incomingList').innerHTML = j.files.map((f) => `<div class="fileitem"><span>📄 ${f.name}</span><span class="muted small">${fmt(f.size)}</span></div>`).join('');
  setRecvState(`Fast mode · ${j.files.length} file(s) · Total ${fmt(recvTotal)}. Check the list, then Accept.`);
  $('#acceptBtn').classList.remove('hidden');
}
async function fastDownloadAll() {
  if (!fastSession) return;
  const startMs = Date.now(); let got = 0;
  $('#recvProgressWrap').classList.remove('hidden');
  for (let i = 0; i < fastSession.files.length; i++) {
    const f = fastSession.files[i];
    const d = await fastApi('/session/download', { code: fastSession.code, index: i });
    // Direct fetch from R2. The Worker is NOT in this path. Stream, verify, then offer.
    const r = await fetch(d.url);
    if (!r.ok) throw new Error('Download failed ' + r.status);
    const reader = r.body.getReader(); const chunks = []; let fileGot = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value); fileGot += value.byteLength; got += value.byteLength;
      const pct = recvTotal ? Math.round(got / recvTotal * 100) : 100;
      $('#recvProgress').style.width = pct + '%';
      $('#recvProgressText').textContent = `Received ${fmt(got)} of ${fmt(recvTotal)} · ${pct}% · ${speedText(got, startMs)} (direct)`;
    }
    const blob = new Blob(chunks, { type: f.type || 'application/octet-stream' });
    if (blob.size !== f.size) throw new Error(`Size mismatch for ${f.name}: got ${blob.size}, expected ${f.size}`);
    let hashOk = null;
    if (f.sha256 && blob.size <= 200 * 1024 * 1024) {
      const buf = await blob.arrayBuffer();
      const h = await crypto.subtle.digest('SHA-256', buf);
      const hex = Array.from(new Uint8Array(h)).map(b => b.toString(16).padStart(2, '0')).join('');
      hashOk = (hex === f.sha256);
      if (!hashOk) throw new Error(`SHA-256 mismatch for ${f.name}. Do not trust this file — ask sender to resend.`);
    }
    // Reuse the existing offer UI by feeding it a completed file record.
    recvFiles[i] = { name: f.name, size: f.size, fileType: f.type, chunks: chunks.map(c => c.buffer.slice(c.byteOffset, c.byteOffset + c.byteLength)), offered: false };
    offerFileDownload(recvFiles[i]);
    if (hashOk) setRecvState(`${f.name}: SHA-256 ✓ MATCH`);
  }
  setRecvState('Fast transfer complete ✓ All files verified by size' + (fastSession.files.every(x => x.sha256) ? ' and SHA-256' : '') + '. Click Download for each file above.');
  toast('Fast transfer complete ✓');
  saveHistory({ direction: 'Received (Fast)', status: 'Completed', files: fastSession.files.map(f => f.name).join(', ') });
  try { await fastApi('/session/delete', { code: fastSession.code }); } catch {}
}

$('#generateBtn').onclick = async () => {
  if (!sendFiles.length) return;
  if (FAST_API) { // Fast mode takes the same button, same code box, same QR.
    sending = true; $('#generateBtn').disabled = true;
    $('#sendStatus').classList.remove('hidden');
    try { await fastSend(); } catch (e) { $('#senderState').textContent = 'Fast upload failed: ' + e.message + ' — check config.js Worker URL and R2 setup, or clear config.js to use P2P.'; sending = false; $('#generateBtn').disabled = false; }
    return;
  }
  const code = String(Math.floor(100000 + Math.random() * 900000));
  const device = ($('#sendDevice').value || '').trim() || 'My device';
  sending = true; $('#generateBtn').disabled = true;
  $('#sendStatus').classList.remove('hidden');
  $('#senderState').textContent = 'Connecting… please wait, code is being created.';
  showCode(code);
  if (typeof Peer === 'undefined') {
    $('#senderState').textContent = 'PeerJS library did not load. Check internet and reload the page.';
    sending = false; $('#generateBtn').disabled = false; return;
  }
  // Use PeerJS defaults (0.peerjs.com, 443, path /) - do not override them.
  senderPeer = new Peer('nova-' + code, PEER_CONFIG);
  senderPeer.on('open', () => { $('#senderState').textContent = 'Code ready. Share it. Waiting for receiver to connect…'; });
  senderPeer.on('error', (err) => {
    const t = err && err.type ? err.type : 'connection error';
    $('#senderState').textContent = 'Connection problem: ' + t + '. Reload and try a new code.';
    if (t === 'unavailable-id') { $('#senderState').textContent = 'This code is already in use. Click Generate again for a new code.'; sending = false; $('#generateBtn').disabled = false; }
  });
  senderPeer.on('connection', (conn) => {
    senderConn = conn;
    conn.on('open', () => { $('#senderState').textContent = 'Receiver connected. Waiting for accept…'; startStats(conn, 'senderDiag', 'upload'); });
    conn.on('error', (e) => { $('#senderState').textContent = 'Connection broke. Keep this page open and ask receiver to reconnect with the same code.'; });
    conn.on('data', async (data) => {
      if (data && data.type === 'hello') {
        conn.send({ type: 'meta', device, files: sendFiles.map(f => ({ name: f.name, size: f.size, type: f.type })) });
        $('#senderState').textContent = 'Receiver saw your files. Waiting for accept…';
      }
      if (data && data.type === 'accept') {
        $('#senderState').textContent = 'Receiver accepted. Sending files…';
        await sendAllFiles(conn);
      }
      if (data && data.type === 'file-received') {
        if (pendingAck) { const r = pendingAck; pendingAck = null; r(); }
      }
    });
    conn.on('close', () => { if (sending) $('#senderState').textContent = 'Receiver disconnected. Keep this page open and ask receiver to reconnect with the same code.'; });
  });
};

function waitForFileAck(timeoutMs) {
  return new Promise((resolve) => {
    pendingAck = resolve;
    setTimeout(() => { if (pendingAck) { pendingAck = null; resolve(); } }, timeoutMs);
  });
}

async function sendAllFiles(conn) {
  const total = sendFiles.reduce((a, f) => a + f.size, 0);
  let sent = 0;
  const startMs = Date.now();
  try {
    for (let fi = 0; fi < sendFiles.length; fi++) {
      const f = sendFiles[fi];
      conn.send({ type: 'file-start', index: fi, name: f.name, size: f.size, fileType: f.type });
      await new Promise(r => setTimeout(r, 50));
      let chunkCount = 0;
      for (let off = 0; off < f.size; off += CHUNK) {
        const slice = f.slice(off, Math.min(off + CHUNK, f.size));
        const buf = await slice.arrayBuffer();
        await waitForBuffer(conn);
        conn.send(buf);
        sent += buf.byteLength; chunkCount++;
        const pct = total ? Math.round(sent / total * 100) : 100;
        $('#sendProgress').style.width = pct + '%';
        $('#sendProgressText').textContent = `Sent ${fmt(sent)} of ${fmt(total)} · ${pct}% · ${speedText(sent, startMs)} · File ${fi + 1} of ${sendFiles.length}`;
        // Yield only every 32 chunks, not after every 16KB chunk.
        if (chunkCount % 32 === 0) await new Promise(r => setTimeout(r, 0));
      }
      conn.send({ type: 'file-end', index: fi });
      // Wait until receiver confirms it actually got all bytes for this file.
      await waitForFileAck(30000);
      $('#senderState').textContent = `File ${fi + 1} of ${sendFiles.length} delivered. Sending next…`;
    }
    conn.send({ type: 'done' });
    $('#senderState').textContent = 'Transfer complete ✓';
    stopStats();
    $('#sendProgress').style.width = '100%';
    toast('Transfer complete ✓');
    saveHistory({ direction: 'Sent', status: 'Completed', files: sendFiles.map(f => f.name).join(', ') });
    sending = false;
  } catch (e) {
    $('#senderState').textContent = 'Transfer failed. Receiver may have closed the page. Try again with a new code.';
    sending = false; $('#generateBtn').disabled = false;
  }
}
$('#cancelSendBtn').onclick = () => {
  stopStats();
  try { senderConn && senderConn.close(); senderPeer && senderPeer.destroy(); } catch {}
  sending = false; $('#senderState').textContent = 'Transfer cancelled.'; $('#generateBtn').disabled = !sendFiles.length;
};

// ---------- RECEIVER ----------
let recvPeer = null, recvConn = null;
let recvMeta = null, recvFiles = {}, recvTotal = 0, recvGot = 0, currentFileIndex = -1, recvStartMs = 0;

function setRecvState(t) { $('#recvState').textContent = t; }
function offerFileDownload(f) {
  const blob = new Blob(f.chunks, { type: f.fileType || 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const wrap = document.createElement('div');
  wrap.className = 'fileitem';
  wrap.style.display = 'block';
  let preview = '';
  if ((f.fileType || '').startsWith('image/')) preview = `<br><img src="${url}" style="max-width:100%;border-radius:10px;margin-top:8px" alt="${f.name}">`;
  else if ((f.fileType || '').startsWith('video/')) preview = `<br><video controls src="${url}" style="max-width:100%;border-radius:10px;margin-top:8px"></video>`;
  else if (f.fileType === 'application/pdf') preview = `<br><a href="${url}" target="_blank" rel="noopener" style="color:#22d3ee">Open PDF in new tab</a>`;
  wrap.innerHTML = `<b>✓ ${f.name}</b> · ${fmt(f.size)} · Complete${preview}<br><a href="${url}" download="${f.name}" class="btn primary" style="display:inline-block;margin-top:10px;text-decoration:none">⬇ Download ${f.name}</a>`;
  $('#downloadList').appendChild(wrap);
}
function checkFileComplete(index) {
  const f = recvFiles[index]; if (!f || f.offered) return;
  const got = f.chunks.reduce((a, c) => a + c.byteLength, 0);
  if (got >= f.size) {
    f.offered = true;
    offerFileDownload(f);
    if (recvConn) { try { recvConn.send({ type: 'file-received', index }); } catch {} }
  }
}

$('#verifyBtn').onclick = async () => {
  const code = ($('#recvCode').value || '').trim();
  if (!/^\d{6}$/.test(code)) { setRecvState('Please enter a valid 6-digit code.'); return; }
  if (FAST_API) { // Fast mode: no PeerJS, no sender-online requirement.
    setRecvState('Fast mode: looking up code…');
    try { await fastReceive(code); } catch (e) { setRecvState('Fast lookup failed: ' + e.message + ' — code expired, wrong, or upload not finished yet.'); }
    return;
  }
  if (typeof Peer === 'undefined') { setRecvState('PeerJS library did not load. Check internet and reload.'); return; }
  setRecvState('Connecting to sender…');
  recvPeer = new Peer(PEER_CONFIG);
  recvPeer.on('open', () => {
    recvConn = recvPeer.connect('nova-' + code);
    recvConn.on('open', () => {
      startStats(recvConn, 'recvDiag', 'download');
      setRecvState('Connected. Asking sender for file list…');
      recvConn.send({ type: 'hello', device: ($('#recvDevice').value || '').trim() || 'Receiver device' });
    });
    recvConn.on('error', () => setRecvState('Connection broke. Ask sender to keep their page open and try again.'));
    recvConn.on('data', onRecvData);
    recvConn.on('close', () => setRecvState('Sender disconnected. Ask sender to keep their page open and connect again.'));
  });
  recvPeer.on('error', (err) => {
    if (err && err.type === 'peer-unavailable') setRecvState('Code not found or sender is not online. Check the code and make sure the sender page is still open.');
    else setRecvState('Connection problem: ' + (err && err.type ? err.type : 'could not connect. Try again.'));
  });
};

async function onRecvData(data) {
  if (data && data.type === 'meta') {
    recvMeta = data; recvTotal = data.files.reduce((a, f) => a + f.size, 0); recvGot = 0; recvFiles = {}; currentFileIndex = -1;
    $('#incomingList').innerHTML = data.files.map((f) => `<div class="fileitem"><span>📄 ${f.name}</span><span class="muted small">${fmt(f.size)}</span></div>`).join('');
    setRecvState(`From ${data.device || 'sender'} · ${data.files.length} file(s) · Total ${fmt(recvTotal)}. Check the list, then Accept.`);
    $('#acceptBtn').classList.remove('hidden');
    return;
  }
  if (data && data.type === 'file-start') {
    currentFileIndex = data.index;
    recvFiles[data.index] = { name: data.name, size: data.size, fileType: data.fileType, chunks: [], offered: false };
    return;
  }
  if (data && data.type === 'file-end') {
    // Do not trust file-end alone. Only offer when bytes are complete.
    checkFileComplete(data.index);
    return;
  }
  if (data && data.type === 'done') {
    setRecvState('Transfer complete ✓ Click Download for each file above. If a file is missing, it did not finish — ask sender to resend with a new code.');
    toast('Transfer complete ✓');
    saveHistory({ direction: 'Received', status: 'Completed', files: recvMeta ? recvMeta.files.map(f => f.name).join(', ') : '' });
    return;
  }
  // Binary chunk: ArrayBuffer, Blob, or Uint8Array — all handled.
  let buf = null;
  if (data instanceof ArrayBuffer) buf = data;
  else if (data instanceof Blob) buf = await data.arrayBuffer();
  else if (data instanceof Uint8Array) buf = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
  else if (data && data.byteLength !== undefined) buf = data;
  if (!buf) return;
  if (currentFileIndex < 0) return;
  const cur = recvFiles[currentFileIndex]; if (!cur) return;
  cur.chunks.push(buf); recvGot += buf.byteLength;
  const pct = recvTotal ? Math.round(recvGot / recvTotal * 100) : 100;
  $('#recvProgressWrap').classList.remove('hidden');
  $('#recvProgress').style.width = pct + '%';
  $('#recvProgressText').textContent = `Received ${fmt(recvGot)} of ${fmt(recvTotal)} · ${pct}% · ${speedText(recvGot, recvStartMs || Date.now())}`;
  checkFileComplete(currentFileIndex);
}
$('#acceptBtn').onclick = async () => {
  if (FAST_API && fastSession) {
    recvStartMs = Date.now();
    setRecvState('Accepted. Downloading directly from storage…');
    $('#acceptBtn').classList.add('hidden');
    try { await fastDownloadAll(); } catch (e) { setRecvState('Fast download failed: ' + e.message); }
    return;
  }
  if (!recvConn) return;
  recvStartMs = Date.now();
  recvConn.send({ type: 'accept' });
  setRecvState('Accepted. Downloading… keep this page open.');
  $('#acceptBtn').classList.add('hidden');
};

try {
  const params = new URLSearchParams(location.search);
  const c = params.get('code');
  if (c && /^\d{6}$/.test(c)) { $('#recvCode').value = c; showTab('receive'); setRecvState('Code filled from QR/link. Click Connect.'); }
} catch {}
