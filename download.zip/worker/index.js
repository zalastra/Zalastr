// NOVA TRANSFER Fast Worker — Cloudflare Workers + R2.
// The Worker NEVER receives or sends file bytes. It only:
//  - creates a 6-digit session and issues presigned PUT URLs (sender -> R2 direct)
//  - verifies R2 objects exist with the right size, then marks the session ready
//  - issues presigned GET URLs (receiver -> R2 direct, Range supported by R2)
// Secrets live ONLY as Worker secrets/env vars, never in frontend code.
// Env vars (wrangler.toml vars + secrets):
//  R2_ACCOUNT_ID, R2_BUCKET, R2_ACCESS_KEY_ID (secret), R2_SECRET_ACCESS_KEY (secret),
//  ALLOWED_ORIGIN (e.g. https://nvt.gt.tc, comma-separated), SESSION_TTL_MINUTES (default 60)
import { S3Client, PutObjectCommand, HeadObjectCommand, GetObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

const MAX_FILES = 5;
const MAX_FILE_BYTES = 500 * 1024 * 1024; // 500 MB per file — raise only if your R2/plan allows it
const MAX_TOTAL_BYTES = 1024 * 1024 * 1024; // 1 GB per session

function s3(env) {
  return new S3Client({
    region: 'auto',
    endpoint: `https://${env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: { accessKeyId: env.R2_ACCESS_KEY_ID, secretAccessKey: env.R2_SECRET_ACCESS_KEY },
  });
}
function cors(env, req) {
  const allowed = (env.ALLOWED_ORIGIN || 'https://nvt.gt.tc').split(',').map(s => s.trim());
  const origin = req.headers.get('Origin') || '';
  const ok = allowed.includes('*') || allowed.includes(origin);
  return { 'Access-Control-Allow-Origin': ok ? origin : allowed[0], 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type', 'Vary': 'Origin' };
}
function json(data, status, headers) {
  return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json', ...headers } });
}
function safeName(name) {
  return String(name || 'file').replace(/[^A-Za-z0-9._-]+/g, '_').slice(0, 120) || 'file';
}
function code() { return String(Math.floor(100000 + Math.random() * 900000)); }
async function readSession(client, env, c) {
  try {
    const o = await client.send(new GetObjectCommand({ Bucket: env.R2_BUCKET, Key: `sessions/${c}.json` }));
    const txt = await o.Body.transformToString();
    return JSON.parse(txt);
  } catch { return null; }
}
async function writeSession(client, env, c, session) {
  await client.send(new PutObjectCommand({ Bucket: env.R2_BUCKET, Key: `sessions/${c}.json`, Body: JSON.stringify(session), ContentType: 'application/json' }));
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const headers = cors(env, req);
    if (req.method === 'OPTIONS') return new Response(null, { headers });
    if (url.pathname === '/health' && req.method === 'GET') return json({ ok: true, mode: 'r2-direct' }, 200, headers);
    if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405, headers);
    let body = {};
    try { body = await req.json(); } catch { return json({ error: 'Invalid JSON' }, 400, headers); }
    const client = s3(env);
    const ttlMin = Number(env.SESSION_TTL_MINUTES || 60);

    if (url.pathname === '/session/create') {
      const files = Array.isArray(body.files) ? body.files : [];
      if (!files.length || files.length > MAX_FILES) return json({ error: '1-5 files required' }, 400, headers);
      let total = 0;
      for (const f of files) { if (!f.size || f.size > MAX_FILE_BYTES) return json({ error: 'File size invalid or over 500 MB' }, 400, headers); total += f.size; }
      if (total > MAX_TOTAL_BYTES) return json({ error: 'Session total over 1 GB' }, 400, headers);
      const c = code();
      const uploads = [];
      for (let i = 0; i < files.length; i++) {
        const key = `uploads/${c}/${i}-${safeName(files[i].name)}`;
        const putUrl = await getSignedUrl(client, new PutObjectCommand({ Bucket: env.R2_BUCKET, Key: key, ContentType: files[i].type || 'application/octet-stream', ContentLength: files[i].size }), { expiresIn: 900 });
        uploads.push({ key, url: putUrl });
      }
      const session = { code: c, device: String(body.device || '').slice(0, 40), createdAt: Date.now(), expiresAt: Date.now() + ttlMin * 60 * 1000, ready: false, files: files.map((f, i) => ({ name: safeName(f.name), size: f.size, type: f.type || 'application/octet-stream', key: uploads[i].key, sha256: null })) };
      await writeSession(client, env, c, session);
      return json({ code: c, uploads: uploads.map(u => ({ url: u.url })), expiresAt: session.expiresAt }, 200, headers);
    }

    if (url.pathname === '/session/complete') {
      const c = String(body.code || '');
      if (!/^\d{6}$/.test(c)) return json({ error: 'Invalid code' }, 400, headers);
      const session = await readSession(client, env, c);
      if (!session) return json({ error: 'Code not found or expired' }, 404, headers);
      if (Date.now() > session.expiresAt) return json({ error: 'Code expired' }, 410, headers);
      const files = Array.isArray(body.files) ? body.files : [];
      if (files.length !== session.files.length) return json({ error: 'File count mismatch' }, 400, headers);
      for (let i = 0; i < files.length; i++) {
        const head = await client.send(new HeadObjectCommand({ Bucket: env.R2_BUCKET, Key: session.files[i].key })).catch(() => null);
        if (!head || head.ContentLength !== session.files[i].size) return json({ error: `Upload not complete for ${session.files[i].name}` }, 400, headers);
        session.files[i].sha256 = files[i].sha256 || null;
      }
      session.ready = true;
      await writeSession(client, env, c, session);
      return json({ ok: true }, 200, headers);
    }

    if (url.pathname === '/session/lookup') {
      const c = String(body.code || '');
      if (!/^\d{6}$/.test(c)) return json({ error: 'Invalid code' }, 400, headers);
      const session = await readSession(client, env, c);
      if (!session) return json({ error: 'Code not found or expired' }, 404, headers);
      if (Date.now() > session.expiresAt) return json({ error: 'Code expired' }, 410, headers);
      if (!session.ready) return json({ error: 'Upload not finished yet' }, 409, headers);
      return json({ code: c, device: session.device, files: session.files.map(f => ({ name: f.name, size: f.size, type: f.type, sha256: f.sha256 })) }, 200, headers);
    }

    if (url.pathname === '/session/download') {
      const c = String(body.code || '');
      const idx = Number(body.index);
      if (!/^\d{6}$/.test(c) || !Number.isInteger(idx)) return json({ error: 'Invalid request' }, 400, headers);
      const session = await readSession(client, env, c);
      if (!session || !session.ready) return json({ error: 'Code not found or not ready' }, 404, headers);
      if (Date.now() > session.expiresAt) return json({ error: 'Code expired' }, 410, headers);
      const f = session.files[idx];
      if (!f) return json({ error: 'File not found' }, 404, headers);
      const getUrl = await getSignedUrl(client, new GetObjectCommand({ Bucket: env.R2_BUCKET, Key: f.key, ResponseContentDisposition: `attachment; filename="${f.name}"` }), { expiresIn: 900 });
      return json({ url: getUrl, name: f.name, size: f.size }, 200, headers);
    }

    if (url.pathname === '/session/delete') {
      const c = String(body.code || '');
      const session = await readSession(client, env, c).catch(() => null);
      if (session) {
        for (const f of session.files) { await client.send(new DeleteObjectCommand({ Bucket: env.R2_BUCKET, Key: f.key })).catch(() => {}); }
        await client.send(new DeleteObjectCommand({ Bucket: env.R2_BUCKET, Key: `sessions/${c}.json` })).catch(() => {});
      }
      return json({ ok: true }, 200, headers);
    }

    return json({ error: 'Not found' }, 404, headers);
  },
};
