# NOVA TRANSFER v3-fast — Real speed fix, exact deploy steps

## 1. Actual bottleneck found (live site https://nvt.gt.tc inspected)
- Live site is v2 P2P: "Nothing is stored on a server", files go sender -> receiver over ONE ordered reliable WebRTC DataChannel via PeerJS.
- v2.2 code: 16KB app chunks, PeerJS `reliable: true` (a second chunking/reassembly layer on top of SCTP, which is already ordered+reliable), and a 4MB backpressure buffer.
- If direct P2P fails (mobile carrier NAT / symmetric NAT, common on phones), PeerJS falls back to its free TURN relay. A free TURN relay is the classic cause of ~0.07 MB/s: 30.4 MB then takes ~7 minutes. No amount of UI or progress-bar work fixes a TURN relay.
- InfinityFree cannot fix this: it is static/PHP hosting, no Node, no WebSocket, no persistent backend. That is why the backend is moved to Cloudflare Workers + R2, while the frontend stays on InfinityFree.

## 2. New architecture (file bytes NEVER go through Worker or InfinityFree)
- Sender: Worker `/session/create` -> presigned PUT URL -> browser uploads BINARY directly to R2 (XHR, real upload progress, no Base64, no copy).
- Sender: Worker `/session/complete` checks R2 HEAD size matches, stores SHA-256 (computed in browser, skipped >200 MB, size check still applies).
- Receiver: Worker `/session/lookup` (code, expiry 60 min) -> file list BEFORE download, same as before.
- Receiver Accept: Worker `/session/download` -> presigned GET URL (15 min) -> browser downloads BINARY directly from R2. R2 supports Range (206) and browser resume.
- Receiver verifies size + SHA-256 (<=200 MB) and only then offers Download. After success, Worker `/session/delete` removes files + session.
- Sender can close the page after upload in Fast mode. In P2P mode sender must still stay online — that limitation remains for P2P only.
- UI, colours, animations, logo, layout, code box, QR, progress bar: unchanged in appearance. Only `config.js` was added (no visual element).

## 3. What changed in code
- `config.js` (NEW): only `window.NOVA_FAST_API`. Empty = P2P only. NEVER put R2 keys here.
- `index.html`: only `<script src="config.js">` added before app.js.
- `app.js`: Fast mode branch on the same Generate/Verify/Accept buttons; P2P chunk 16KB -> 64KB, `reliable: true` -> `reliable: false`.
- `worker/index.js` (NEW, Cloudflare Workers): S3 presigning via @aws-sdk, session create/complete/lookup/download/delete, CORS, 500 MB/file, 1 GB/session, 60 min expiry, 15 min URLs.
- `worker/wrangler.toml`, `worker/package.json` (NEW).
- `test/mock-server.mjs`, `test/test-fast.mjs` (NEW, local test only, not deployed).

## 4. Exact deployment — do in this order, one step at a time
### A. Cloudflare R2 bucket
1. Cloudflare Dashboard > R2 > Create bucket, name: nova-transfer
2. R2 > Manage R2 API Tokens > Create API Token, Object Read & Write, apply to bucket nova-transfer. Copy Access Key ID and Secret Access Key ONCE (you will not see the secret again).
3. Note your Account ID from the R2 overview page (also in the dashboard URL).
4. Optional but recommended: R2 > bucket > Settings > Object Lifecycle: delete objects after 1 day, as a second cleanup layer.

### B. Worker
1. Install wrangler on your PC: `npm install -g wrangler`
2. Login: `wrangler login`
3. Go into the worker folder: `cd worker`
4. Install deps: `npm install`
5. Set secrets (values are NOT written in any file):
   - `wrangler secret put R2_ACCOUNT_ID`
   - `wrangler secret put R2_BUCKET`  (type: nova-transfer)
   - `wrangler secret put R2_ACCESS_KEY_ID`
   - `wrangler secret put R2_SECRET_ACCESS_KEY`
6. Edit `wrangler.toml` ONLY if your frontend origin is not https://nvt.gt.tc: change ALLOWED_ORIGIN to your InfinityFree domain, e.g. https://yoursite.infinityfreeapp.com
7. Deploy: `wrangler deploy`
8. Copy the Worker URL, e.g. https://nvt-api.YOURNAME.workers.dev
9. Test health: open https://nvt-api.YOURNAME.workers.dev/health — it must show {"ok":true,"mode":"r2-direct"}

### C. Frontend (InfinityFree)
1. Open `config.js` and set ONLY this line: `window.NOVA_FAST_API = 'https://nvt-api.YOURNAME.workers.dev';`
2. Upload ALL frontend files to InfinityFree public_html (or your site folder), flat, no nested folder: index.html, styles.css, app.js, config.js, logo.png, favicon.png
3. Do NOT upload `worker/` or `test/` to InfinityFree. They are not frontend files.
4. Hard refresh the site (Ctrl+Shift+R) so the old config.js is not cached.
5. Rate limiting (important, Worker isolates are stateless): Cloudflare Dashboard > Security > WAF > Rate limiting rules > Create rule for hostname = your Worker hostname, limit e.g. 30 requests per minute per IP on /session/*, action Block for 10 minutes. This is the production rate limit; the Worker code itself does not fake a cross-isolate counter.

## 5. Live test you must run (do NOT trust the local test alone)
1. Send a 30.4 MB file in Fast mode, note upload MB/s shown on the progress line.
2. On the receiver, Accept, note download MB/s, wait for SHA-256 ✓ MATCH.
3. Download the same file again via the direct link and compare size.
4. Try an expired/wrong code: it must return Code not found / Code expired, not a file.
If live R2 speed is still low, the remaining bottleneck is your sender/receiver network or R2 region, not the app server — because file bytes no longer pass through any app server. Report the live MB/s, device, and network (WiFi/4G) and we will tune from real numbers.

## 6. Test results — honest, no faking
- BEFORE (user-reported live P2P): 30.4 MB at ~0.07 MB/s. This was NOT re-measured by the assistant on live, because live TURN routing depends on your two devices/network at that moment.
- AFTER (local mock R2, SAME 30.4 MB file, SAME code flow): upload 200 in 0.32 s, Range test 206, download 31,876,710 bytes in 0.19 s = 156.70 MB/s, SHA-256 MATCH: YES (original c3cf1b54e6c0b94ff47eb1527496745d1d7d43ff28f3a5bf9a8c78120f7ffa5a).
- IMPORTANT: 156.70 MB/s is LOCAL LOOPBACK (same machine), NOT a live network promise and NOT a claim that live R2 will hit 100 MB/s for you. 100 MB/s live is only possible if sender, receiver, R2 edge, and network genuinely support 800 Mbps. The architecture removes the TURN/app-server cap; it cannot create bandwidth your network does not have.
- Worker SigV4/SDK code: syntax-checked only. Live R2 presign test is PENDING your bucket + secrets (step 4A/4B above). Until you run step 5, do NOT treat live Fast mode as verified.

## 7. Remaining limitations
- Fast mode needs R2 + Worker configured. Without config.js set, site works in P2P mode only, with the same TURN risk.
- SHA-256 is skipped for files >200 MB in browser (size check still applies); use the direct download + size check for very large files.
- R2 presigned URLs are short-lived (15 min). If a download takes longer, request a fresh download URL by clicking Accept again.
- Simultaneous transfers: each session has its own random 6-digit code and its own R2 prefix uploads/<code>/, so sessions do not overwrite each other. Two sessions could theoretically collide on the same 6-digit code (1 in 900,000); if create returns an existing code, the Worker currently overwrites — in production, add a KV check or use a longer internal key. This is a known, documented risk, not hidden.

## 8. v3.1 diagnostics update (WebRTC getStats, ICE correction)
- Inspection: transfer is WebRTC DataChannel (PeerJS), NOT WebSocket file relay and NOT HTTP upload. Signalling is WebSocket/HTTPS to 0.peerjs.com only; file bytes are binary ArrayBuffer/Blob over SCTP, no Base64.
- ICE before: PeerJS defaults, STUN only, no TURN configured in code. That means a slow relay is NOT proven by code alone — if a relay appears in getStats, it must be coming from the browser/PeerJS cloud default at runtime, which is why v3.1 now SHOWS it instead of guessing.
- ICE after: explicit STUN (Google + Cloudflare), NO TURN added. Adding more STUN servers does NOT increase throughput. TURN, if you add one, is a paid/shared relay: bandwidth is capped by that server, latency rises, and cost is per GB relayed. Do not silently add a free TURN and expect direct speed.
- getStats shown live (1s poll, local only): Route Direct/Relay, RTT ms, packet loss %, channel upload/download MB/s, separate from app MB/s. If app MB/s is much lower than channel MB/s, app chunking/backpressure is the bottleneck. If channel MB/s itself is 0.16 MB/s, the path/sender-upload is the bottleneck.
- Sender vs receiver: in P2P, receiver download speed CANNOT exceed sender upload speed. If sender is on 4G with ~1-2 Mbps upload, receiver will see ~0.12-0.25 MB/s even with perfect code. That matches your 0.07 and 0.16 MB/s reports (two runs, different networks/times, not a fixed code speed). Fast R2 mode separates the two: upload is still limited by sender upload, but download from R2 afterwards is NOT limited by sender, and sender can go offline.
- v3 correction: reliable:false reverted to default reliable:true for file integrity.
- Live P2P diagnostic test: NOT yet run on your two real devices. Run it with v3.1, send 30.4 MB, screenshot senderDiag and recvDiag at 10s, 30s, and at completion, and send those three numbers (route, RTT, loss, channel MB/s) — that one run will prove direct vs relay, without guessing.
