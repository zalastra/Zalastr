/**
 * Repair tests for NOVA TRANSFER (Stage D).
 * Run against a server already running on BASE (default http://localhost:3000):
 *   npm start   (terminal 1)
 *   node test-repair.mjs   (terminal 2)
 * Covers: config/LAN URLs, QR + barcode PNG + JSON (token-gated),
 * verify success/failure, unauthorized download, .env loading and
 * expiry — the last two via short-lived child servers on other ports,
 * which are killed and cleaned up by this script.
 * Exits non-zero on any failure. No real OTP/email is used.
 */
import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const BASE = process.env.BASE || 'http://localhost:3000';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const assert = (c, m) => { if (!c) throw new Error('FAIL: ' + m); };
const pngSig = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function waitHealth(port, tries = 30) {
  for (let i = 0; i < tries; i++) {
    try { const r = await fetch(`http://localhost:${port}/api/health`); if (r.ok) return; } catch {}
    await sleep(200);
  }
  throw new Error('server on port ' + port + ' did not start');
}
function startServer(port, extraEnv = {}) {
  const child = spawn(process.execPath, ['server.js'], {
    cwd: __dirname, env: { ...process.env, PORT: String(port), ...extraEnv }, stdio: 'ignore',
  });
  return child;
}

// 1. Config + LAN URLs
const cfg = await (await fetch(`${BASE}/api/config`)).json();
assert(cfg.ttlMinutes === 15, 'config ttl should be 15 by default, got ' + cfg.ttlMinutes);
assert(Array.isArray(cfg.lanUrls), 'config must include lanUrls array');
console.log('✓ config ok, lanUrls:', cfg.lanUrls.join(', ') || '(none in this VM)');

// 2. Create a session, upload one small file, verify it
const data = Buffer.from('repair-test-file-content');
const created = await (await fetch(`${BASE}/api/sessions`, {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ deviceName: 'Repair Test', files: [{ name: 'repair.txt', size: data.length, type: 'text/plain' }] }),
})).json();
assert(/^\d{6}$/.test(created.code), 'code must be 6 digits');
const up = await fetch(`${BASE}/api/sessions/${created.sessionId}/chunks`, {
  method: 'POST',
  headers: { 'x-upload-token': created.uploadToken, 'x-file-index': 0, 'x-chunk-index': 0, 'x-total-chunks': 1, 'Content-Type': 'application/octet-stream' },
  body: data,
});
assert(up.ok, 'chunk upload failed ' + up.status);
const meta = await (await fetch(`${BASE}/api/sessions/verify`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: created.code }) })).json();
assert(meta.status === 'ready', 'expected ready after upload, got ' + meta.status);
assert(meta.files[0].sha256, 'streaming SHA-256 must be present');
console.log('✓ verify + streaming SHA ok, sha256', meta.files[0].sha256.slice(0, 16) + '…');

// 3. QR + barcode: PNG, JSON, and token gating
for (const kind of ['qr', 'barcode']) {
  const pngRes = await fetch(`${BASE}/api/sessions/${created.sessionId}/${kind}?token=${created.uploadToken}`);
  assert(pngRes.ok && pngRes.headers.get('content-type') === 'image/png', kind + ' PNG failed ' + pngRes.status);
  const buf = Buffer.from(await pngRes.arrayBuffer());
  assert(buf.length > 500 && buf.subarray(0, 8).equals(pngSig), kind + ' is not a valid PNG');
  const jsonRes = await fetch(`${BASE}/api/sessions/${created.sessionId}/${kind}?token=${created.uploadToken}&format=json`);
  const j = await jsonRes.json();
  if (kind === 'qr') {
    assert(j.url && j.url.includes('code=' + created.code) && j.url.includes('view=receive'), 'QR URL must encode code+view, got ' + j.url);
    console.log('✓ QR ok, url:', j.url);
  } else {
    assert(j.code === created.code, 'barcode JSON code must match');
    console.log('✓ barcode ok, code:', j.code);
  }
  const noToken = await fetch(`${BASE}/api/sessions/${created.sessionId}/${kind}`);
  assert(noToken.status === 403, kind + ' without token must be 403, got ' + noToken.status);
  const badToken = await fetch(`${BASE}/api/sessions/${created.sessionId}/${kind}?token=wrong`);
  assert(badToken.status === 403, kind + ' with wrong token must be 403, got ' + badToken.status);
}
console.log('✓ QR/barcode token gating ok');

// 4. Unauthorized download + wrong code
const noDl = await fetch(`${BASE}/api/sessions/${created.sessionId}/files/0`);
assert(noDl.status === 403, 'download without accept must be 403, got ' + noDl.status);
const wrong = await fetch(`${BASE}/api/sessions/verify`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: '000000' }) });
assert(wrong.status === 404, 'wrong code must be 404, got ' + wrong.status);
console.log('✓ unauthorized download + wrong code rejected');

// 5. Clean up the test session
await fetch(`${BASE}/api/sessions/${created.sessionId}`, { method: 'DELETE', headers: { 'x-upload-token': created.uploadToken } });

// 6. Expiry on a short-TTL child server (TTL ~0.06s)
{
  const child = startServer(3101, { TRANSFER_TTL_MINUTES: '0.001' });
  try {
    await waitHealth(3101);
    const c = await (await fetch('http://localhost:3101/api/sessions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ deviceName: 'Expiry', files: [{ name: 'e.txt', size: 3, type: 'text/plain' }] }) })).json();
    await sleep(400);
    const v = await fetch('http://localhost:3101/api/sessions/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: c.code }) });
    assert(v.status === 404, 'expired code must be 404, got ' + v.status);
    console.log('✓ expired code rejected (short-TTL server)');
  } finally { child.kill('SIGTERM'); }
}

// 7. .env loading on a child server
{
  const envPath = path.join(__dirname, '.env');
  const hadEnv = fs.existsSync(envPath);
  const oldEnv = hadEnv ? fs.readFileSync(envPath, 'utf8') : null;
  fs.writeFileSync(envPath, 'TRANSFER_TTL_MINUTES=99\n');
  const child = startServer(3102);
  try {
    await waitHealth(3102);
    const c2 = await (await fetch('http://localhost:3102/api/config')).json();
    assert(c2.ttlMinutes === 99, '.env TTL must be 99, got ' + c2.ttlMinutes);
    console.log('✓ .env loading ok (TTL=99 from .env)');
  } finally {
    child.kill('SIGTERM');
    if (hadEnv) fs.writeFileSync(envPath, oldEnv); else fs.unlinkSync(envPath);
  }
}

console.log('\nALL REPAIR TESTS PASSED');
