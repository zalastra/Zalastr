# NOVA TRANSFER — deploy guide (Render)

## Important: do not deploy this project as a Cloudflare Worker

This project is a Node.js + Express server. It uses `http.createServer`, a `ws` WebSocket server, Node filesystem APIs, and temporary disk storage. A standard Cloudflare Worker is not a drop-in host for this server, so uploading `server.js` as a Worker can result in a deployed URL that does not work.

Cloudflare Pages is suitable for static HTML/CSS/JS sites, but NOVA TRANSFER needs its backend running too. Use a Node.js host for this ZIP.

## Deploy on Render (free tier)

1. Extract this ZIP on your computer.
2. Create a GitHub repository and upload the contents of the `nova-transfer` folder (the files inside it, not an extra nested folder).
3. Open https://render.com/ and sign in.
4. Choose **New + → Web Service**, then connect your GitHub repository.
5. Use these settings:
   - Runtime: **Node**
   - Build command: `npm ci`
   - Start command: `npm start`
   - Health check path: `/api/health`
6. Deploy. Open the `onrender.com` URL Render provides.

The included `render.yaml` also defines these settings for Render Blueprint deployment.

## Free-tier limitations

- A free service may sleep after inactivity, so the first visit can take a little time to start.
- Local disk and in-memory transfer sessions are temporary. If the service restarts or sleeps, an active transfer may fail; don't use it as permanent storage.
- This app relays uploaded files through the server. Large files use server disk and bandwidth, so test with small non-sensitive files first.
- A custom domain is optional; the free `onrender.com` address is enough to test.

## Local test on Windows

Install Node.js 18+ then, in the extracted project folder, run:

```bash
npm ci
npm start
```

Open http://localhost:3000. To run the end-to-end test, keep the server running and open a second terminal in the project folder:

```bash
npm test
```

## Troubleshooting

- **URL opens but buttons don't work:** make sure you deployed the entire repository, including `server.js`, `package.json`, `package-lock.json`, and the `public` folder.
- **404 on `/api/health`:** the host is serving only static files or the wrong root directory.
- **WebSocket errors:** use the deployed HTTPS URL; the frontend automatically uses `wss://` on HTTPS.
- **Transfer fails after a while:** free services can sleep/restart, and session state is in memory. Retry with small files; for reliable production use, migrate session state to durable storage and files to object storage such as Cloudflare R2.
