/**
 * End-to-end test for NOVA TRANSFER (no test framework needed).
 * Run with the server already running:  npm start  (in another terminal)
 * then:  npm test
 * It exercises the real flow: create -> chunk-upload -> verify (wrong + right)
 * -> accept before ready is rejected -> accept -> download -> byte-for-byte check
 * -> cancel deletes the session. Exits non-zero on any failure.
 */
const BASE = process.env.BASE || 'http://localhost:3000';
const assert = (c, m) => { if (!c) throw new Error('FAIL: ' + m); };
const json = async (r) => { try { return await r.json(); } catch { return {}; } };

const data = Buffer.from('Hello NOVA — a real file, not a simulation. '.repeat(20000)); // ~900 KB
const chunk = async (sessionId, token, file, ci, total) => {
  const r = await fetch(`${BASE}/api/sessions/${sessionId}/chunks`, {
    method: 'POST',
    headers: { 'x-upload-token': token, 'x-file-index': 0, 'x-chunk-index': ci, 'x-total-chunks': total, 'Content-Type': 'application/octet-stream' },
    body: file.subarray(ci * 1024 * 1024, (ci + 1) * 1024 * 1024),
  });
  if (!r.ok) throw new Error('chunk upload ' + r.status + ' ' + await r.text());
  return r.json();
};

const created = await (await fetch(`${BASE}/api/sessions`, {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ deviceName: 'Test Sender', files: [{ name: 'hello.txt', size: data.length, type: 'text/plain' }] }),
})).json();
assert(/^\d{6}$/.test(created.code), 'code must be 6 digits, got ' + created.code);
console.log('✓ session created, code', created.code);

// Wrong code must not leak anything
const wrong = await fetch(`${BASE}/api/sessions/verify`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: '000000' }) });
assert(wrong.status === 404, 'wrong code should be 404, got ' + wrong.status);
console.log('✓ wrong code rejected');

// Accept before upload finishes must be rejected (no silent transfer)
const early = await fetch(`${BASE}/api/sessions/${created.sessionId}/accept`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: created.code }) });
assert(early.status === 409, 'early accept should be 409, got ' + early.status);
console.log('✓ accept before ready rejected');

// Upload in 1 MiB chunks, then verify the upload is complete
const totalChunks = Math.ceil(data.length / (1024 * 1024));
for (let i = 0; i < totalChunks; i++) await chunk(created.sessionId, created.uploadToken, data, i, totalChunks);
const meta = await (await fetch(`${BASE}/api/sessions/verify`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: created.code }) })).json();
assert(meta.status === 'ready', 'expected ready, got ' + meta.status);
assert(meta.files[0].sha256, 'server should report a SHA-256');
console.log('✓ verified, status ready, sha256', meta.files[0].sha256.slice(0, 16) + '…');

// Download without accept token must fail; with it, bytes must match exactly
const noToken = await fetch(`${BASE}/api/sessions/${created.sessionId}/files/0`);
assert(noToken.status === 403, 'download without accept should be 403, got ' + noToken.status);
const accepted = await (await fetch(`${BASE}/api/sessions/${created.sessionId}/accept`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: created.code }) })).json();
assert(accepted.acceptToken, 'accept must return a token');
const dl = await fetch(`${BASE}/api/sessions/${created.sessionId}/files/0?token=${accepted.acceptToken}`);
assert(dl.ok, 'download failed ' + dl.status);
const got = Buffer.from(await dl.arrayBuffer());
assert(got.equals(data), `downloaded bytes differ (${got.length} vs ${data.length})`);
console.log('✓ downloaded bytes match uploaded bytes exactly');

// Cancel a second session and confirm it is gone
const c2 = await (await fetch(`${BASE}/api/sessions`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ deviceName: 'T2', files: [{ name: 'x.txt', size: 3, type: 'text/plain' }] }) })).json();
const cancelled = await fetch(`${BASE}/api/sessions/${c2.sessionId}`, { method: 'DELETE', headers: { 'x-upload-token': c2.uploadToken } });
assert(cancelled.ok, 'cancel failed');
const cancelledStatus = await (await fetch(`${BASE}/api/sessions/${c2.sessionId}/status?token=${c2.uploadToken}`)).json();
assert(cancelledStatus.status === 'cancelled', 'cancelled session should report cancelled, got ' + JSON.stringify(cancelledStatus));
await new Promise(r => setTimeout(r, 6000)); // tombstone window, so live clients see the final state
const gone = await fetch(`${BASE}/api/sessions/${c2.sessionId}/status?token=${c2.uploadToken}`);
assert(gone.status === 404, 'cancelled session should be gone after tombstone, got ' + gone.status);
console.log('✓ cancel works');
console.log('\nALL TESTS PASSED');
