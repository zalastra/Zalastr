/* NOVA TRANSFER — frontend (vanilla, no build step).
   Honest progress: upload/download speeds are measured from real bytes
   over real time. Nothing is marked complete until the server confirms it. */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const CHUNK = 1024 * 1024;
const fmt = n => n < 1024 ? n + ' B' : n < 1048576 ? (n/1024).toFixed(1)+' KB' : n < 1073741824 ? (n/1048576).toFixed(1)+' MB' : (n/1073741824).toFixed(2)+' GB';
const fmtSpeed = bps => bps <= 0 ? '—' : fmt(bps) + '/s';
const fmtEta = s => !isFinite(s) || s <= 0 ? '—' : s < 60 ? Math.ceil(s)+'s' : Math.floor(s/60)+'m '+Math.ceil(s%60)+'s';
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let toastTimer;
function toast(msg){ const t=$('#toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.classList.remove('show'),4200); }
// FIX: raw "Failed to fetch" tells the user nothing. Map network failures
// to an actionable message; keep real server errors verbatim.
function networkError(e){
  const m = String(e && e.message || e || '');
  if (e instanceof TypeError || /failed to fetch|networkerror|network request failed/i.test(m)) {
    return 'Server se connect nahi ho raha. Check karo: server chal raha hai, hotspot / Wi-Fi connected hai, aur address sahi hai.';
  }
  return m || 'Something went wrong. Please try again.';
}
function setBusy(btn, busy, busyText){
  if (busy) { if (!btn.dataset.orig) btn.dataset.orig = btn.textContent; btn.textContent = busyText; btn.disabled = true; }
  else { if (btn.dataset.orig) btn.textContent = btn.dataset.orig; btn.disabled = false; }
}
function saveHistory(entry){
  const h = JSON.parse(localStorage.getItem('nova_history')||'[]');
  h.unshift({time:new Date().toISOString(), ...entry});
  localStorage.setItem('nova_history', JSON.stringify(h.slice(0,100)));
  renderHistory();
}
function saveActive(entry){
  const a = JSON.parse(localStorage.getItem('nova_active')||'[]');
  const i = a.findIndex(x=>x.sessionId===entry.sessionId);
  if(i>=0) a[i]={...a[i],...entry}; else a.unshift(entry);
  localStorage.setItem('nova_active', JSON.stringify(a.slice(0,30)));
  renderActive();
}

// ---------- theme ----------
function applyTheme(){
  const pref = localStorage.getItem('nova_theme') || 'dark';
  const theme = pref==='system' ? (matchMedia('(prefers-color-scheme: light)').matches?'light':'dark') : pref;
  document.documentElement.dataset.theme = theme;
  $('#themeSelect').value = pref;
}
$('#themeBtn').onclick = () => {
  const cur = document.documentElement.dataset.theme;
  localStorage.setItem('nova_theme',''+(cur==='dark'?'light':'dark')); applyTheme();
};
$('#themeSelect').onchange = e => { localStorage.setItem('nova_theme', e.target.value); applyTheme(); };
$('#reduceMotion').onchange = e => { localStorage.setItem('nova_reduce', e.target.checked?'1':'0'); startParticles(); };

// ---------- navigation ----------
function show(view){
  $$('.view').forEach(v=>v.classList.remove('active'));
  $$('.tab').forEach(t=>t.classList.toggle('active', t.dataset.nav===view));
  $('#view-'+view).classList.add('active');
  if(view==='active') renderActive();
  if(view==='history') renderHistory();
  window.scrollTo({top:0, behavior:'smooth'});
}
$$('[data-nav]').forEach(el=>el.addEventListener('click', e=>{ e.preventDefault(); show(el.dataset.nav); }));

// ---------- particles (lightweight, pauses when tab hidden / reduced motion) ----------
let particleRAF;
function startParticles(){
  cancelAnimationFrame(particleRAF);
  const c = $('#particles'), ctx = c.getContext('2d');
  if (localStorage.getItem('nova_reduce')==='1' || matchMedia('(prefers-reduced-motion: reduce)').matches) { ctx.clearRect(0,0,c.width,c.height); return; }
  const dpr = Math.min(devicePixelRatio||1, 1.5);
  const resize = ()=>{ c.width=innerWidth*dpr; c.height=innerHeight*dpr; c.style.width=innerWidth+'px'; c.style.height=innerHeight+'px'; };
  resize(); addEventListener('resize', resize);
  const pts = Array.from({length: Math.min(42, Math.floor(innerWidth/28))}, ()=>({x:Math.random()*c.width, y:Math.random()*c.height, vx:(Math.random()-.5)*.25*dpr, vy:(Math.random()-.5)*.25*dpr, r:(1+Math.random()*1.6)*dpr}));
  (function tick(){
    if(document.hidden){ particleRAF=requestAnimationFrame(tick); return; }
    ctx.clearRect(0,0,c.width,c.height); ctx.fillStyle='rgba(124,92,255,.55)';
    for(const p of pts){ p.x+=p.vx; p.y+=p.vy; if(p.x<0||p.x>c.width) p.vx*=-1; if(p.y<0||p.y>c.height) p.vy*=-1; ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,7); ctx.fill(); }
    particleRAF=requestAnimationFrame(tick);
  })();
}

// ---------- config / device ----------
let CONFIG = null;
async function loadConfig(){
  try{
    CONFIG = await (await fetch('/api/config')).json();
    $('#serverLimits').textContent = `Server limits: ${CONFIG.maxFileMB} MB per file · ${CONFIG.maxTotalMB} MB per transfer · codes expire in ${CONFIG.ttlMinutes} minutes.`;
    $('#settingsLimits').textContent = `Server limits: ${CONFIG.maxFileMB} MB per file · ${CONFIG.maxTotalMB} MB per transfer · ${CONFIG.maxFiles} files max · codes expire in ${CONFIG.ttlMinutes} minutes.`;
    if (CONFIG.lanUrls && CONFIG.lanUrls.length) {
      $('#lanUrls').textContent = 'On another device on the same Wi-Fi / hotspot, open: ' + CONFIG.lanUrls.join('  or  ');
    }
  }catch{ $('#serverLimits').textContent = 'Server limits could not be loaded — transfers need the backend running (see README).'; }
}
$('#settingDevice').oninput = e => { localStorage.setItem('nova_device', e.target.value); $('#sendDevice').value = e.target.value; };
$('#sendDevice').oninput = e => { localStorage.setItem('nova_device', e.target.value); $('#settingDevice').value = e.target.value; };
function deviceName(){ return (localStorage.getItem('nova_device')||'').trim() || (navigator.userAgent.includes('Android')?'Android device':navigator.userAgent.includes('iPhone')?'iPhone':'My device'); }

// ---------- SEND ----------
let sendFiles = [], sendSession = null, sendCancelled = false, sendFailed = false;
const sendInput = $('#fileInput');
// FIX: preview object URLs were created on every render and never revoked.
const previewUrls = new Map();
function previewUrl(f){
  if (!previewUrls.has(f)) previewUrls.set(f, URL.createObjectURL(f));
  return previewUrls.get(f);
}
function revokePreview(f){ if (previewUrls.has(f)) { URL.revokeObjectURL(previewUrls.get(f)); previewUrls.delete(f); } }
function renderSendList(){
  $('#sendList').innerHTML = sendFiles.map((f,i)=>`
    <div class="file-item">
      ${f.type.startsWith('image/') ? `<img src="${previewUrl(f)}" alt="">` : `<span aria-hidden="true">📄</span>`}
      <div class="meta"><b>${esc(f.name)}</b><span class="muted small">${esc(f.type||'Unknown type')} · ${fmt(f.size)}</span></div>
      <button class="btn ghost" data-remove="${i}" aria-label="Remove ${esc(f.name)}">✕</button>
    </div>`).join('');
  $$('#sendList [data-remove]').forEach(b=>b.onclick=()=>{ const removed = sendFiles[+b.dataset.remove]; sendFiles.splice(+b.dataset.remove,1); revokePreview(removed); renderSendList(); updateSendUI(); });
  const total = sendFiles.reduce((a,f)=>a+f.size,0);
  $('#sendTotal').textContent = sendFiles.length ? `${sendFiles.length} file(s) · Total ${fmt(total)}` : '';
  updateSendUI();
}
function updateSendUI(){
  // Only block Generate while an upload is actually in progress.
  // A finished / cancelled / expired session must NOT block a new code —
  // that was the bug: the old check waited for a status ('done') that never occurs.
  const uploading = sendSession && sendSession.status === 'uploading';
  $('#generateBtn').disabled = !sendFiles.length || uploading;
  $('#clearSendBtn').disabled = !sendFiles.length;
}
function addFiles(list){ for(const f of list) if(!sendFiles.some(x=>x.name===f.name && x.size===f.size)) sendFiles.push(f); renderSendList(); }
sendInput.onchange = e => addFiles(e.target.files);
const dz = $('#dropzone');
['dragover','dragenter'].forEach(ev=>dz.addEventListener(ev, e=>{ e.preventDefault(); dz.classList.add('over'); }));
['dragleave','drop'].forEach(ev=>dz.addEventListener(ev, e=>{ e.preventDefault(); dz.classList.remove('over'); }));
dz.addEventListener('drop', e=>addFiles(e.dataTransfer.files));
$('#clearSendBtn').onclick = ()=>{ for (const f of sendFiles) revokePreview(f); sendFiles=[]; sendSession=null; clearInterval(pollTimer); $('#sendSession').classList.add('hidden'); renderSendList(); };

let ws = null, pollTimer = null;
function startPolling(){
  clearInterval(pollTimer);
  pollTimer = setInterval(async ()=>{
    if(!sendSession) return;
    try{
      const r = await fetch(`/api/sessions/${sendSession.sessionId}/status?token=${sendSession.uploadToken}`);
      if(r.ok) onSenderStatus(await r.json());
    }catch{}
  }, 3000);
}
function stopPolling(){ clearInterval(pollTimer); pollTimer = null; }
// FIX: WS and polling previously ran at the same time, doubling status
// requests. Polling is now only a fallback while WS is not open.
function connectLive(sessionId, token){
  try{ ws?.close(); }catch{}
  startPolling();
  try{
    ws = new WebSocket(`${location.protocol==='https:'?'wss:':'ws:'}//${location.host}/ws?sessionId=${sessionId}&token=${token}`);
    ws.onopen = ()=> stopPolling();
    ws.onmessage = e => { try{ const d=JSON.parse(e.data); if(d.session) onSenderStatus(d.session); }catch{} };
    ws.onerror = ()=>{};
    ws.onclose = ()=>{ if (sendSession) startPolling(); };
  }catch{}
}
function onSenderStatus(s){
  if(!sendSession) return;
  sendSession.status = s.status;
  const pct = s.progress;
  $('#sendPct').textContent = pct+'%';
  $('#ringFg').style.strokeDashoffset = 327 - (327*pct/100);
  $('#sendBar').style.width = pct+'%';
  $('#sendBytes').textContent = `${fmt(s.receivedBytes)} / ${fmt(s.totalSize)}`;
  const label = {uploading:'Uploading…', ready:'Ready — waiting for receiver to accept', accepted:'Receiver accepted — ready to download', downloading:'Receiver is downloading…', completed:'✓ Transfer complete', cancelled:'Transfer cancelled', expired:'Code expired'}[s.status] || s.status;
  $('#sendStatus').textContent = label;
  saveActive({sessionId:s.sessionId, direction:'Sent', device:s.deviceName, status:label, files:s.files.map(f=>f.name).join(', '), total:s.totalSize});
  if(s.status==='completed'){ saveHistory({direction:'Sent', device:s.deviceName, status:'Completed', files:s.files.map(f=>f.name).join(', '), total:s.totalSize}); toast('Transfer complete ✓'); }
  if(s.status==='cancelled' || s.status==='expired'){ clearInterval(pollTimer); }
  updateSendUI();
}
async function uploadAll(){
  sendCancelled = false; sendFailed = false;
  const started = performance.now(); let uploadedBefore = 0;
  for(let fi=0; fi<sendFiles.length; fi++){
    const file = sendFiles[fi]; const chunks = Math.ceil(file.size/CHUNK);
    // Resume: ask the server how far this file already got.
    let startChunk = 0;
    try{
      const st = await (await fetch(`/api/sessions/${sendSession.sessionId}/status?token=${sendSession.uploadToken}`)).json();
      const sf = st.files?.[fi]; if(sf && sf.receivedBytes) startChunk = Math.floor(sf.receivedBytes/CHUNK);
    }catch{}
    for(let ci=startChunk; ci<chunks; ci++){
      if(sendCancelled) return;
      const slice = file.slice(ci*CHUNK, (ci+1)*CHUNK);
      let ok = false;
      for(let attempt=0; attempt<3 && !ok; attempt++){
        try{
          const r = await fetch(`/api/sessions/${sendSession.sessionId}/chunks`, {method:'POST', headers:{'x-upload-token':sendSession.uploadToken,'x-file-index':fi,'x-chunk-index':ci,'x-total-chunks':chunks,'Content-Type':'application/octet-stream'}, body: slice});
          if(!r.ok){ const e=await r.json().catch(()=>({})); throw new Error(e.error||('Upload failed ('+r.status+')')); }
          ok = true;
        }catch(err){ if(attempt===2){ sendFailed=true; $('#retrySendBtn').classList.remove('hidden'); toast('Upload failed: '+networkError(err)); return; } await new Promise(r=>setTimeout(r, 800*(attempt+1))); }
      }
      const uploaded = uploadedBefore + (ci+1)*CHUNK > file.size ? uploadedBefore + file.size : uploadedBefore + (ci+1)*CHUNK;
      // Simpler, honest aggregate: recompute from the server on each chunk is costly; use local count + prior files.
      const totalDone = sendFiles.slice(0,fi).reduce((a,f)=>a+f.size,0) + Math.min((ci+1)*CHUNK, file.size);
      const total = sendFiles.reduce((a,f)=>a+f.size,0);
      const pct = Math.round(totalDone/total*100);
      const elapsed = (performance.now()-started)/1000, speed = elapsed>0 ? totalDone/elapsed : 0;
      $('#sendPct').textContent = pct+'%'; $('#ringFg').style.strokeDashoffset = 327-(327*pct/100); $('#sendBar').style.width = pct+'%';
      $('#sendBytes').textContent = `${fmt(totalDone)} / ${fmt(total)}`; $('#sendSpeed').textContent = fmtSpeed(speed); $('#sendEta').textContent = speed>0 ? fmtEta((total-totalDone)/speed) : '—';
      $('#sendStatus').textContent = 'Uploading…';
    }
    uploadedBefore += file.size;
  }
  $('#sendStatus').textContent = 'Upload complete — waiting for receiver to accept';
  $('#sendSpeed').textContent = '—'; $('#sendEta').textContent = '—';
  connectLive(sendSession.sessionId, sendSession.uploadToken);
  // Final status from server (the source of truth, not the local counter)
  try{ const st = await (await fetch(`/api/sessions/${sendSession.sessionId}/status?token=${sendSession.uploadToken}`)).json(); onSenderStatus(st); }catch{}
}
$('#generateBtn').onclick = async ()=>{
  if(!sendFiles.length) return;
  $('#generateBtn').disabled = true;
  try{
    const r = await fetch('/api/sessions', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({deviceName: deviceName(), files: sendFiles.map(f=>({name:f.name,size:f.size,type:f.type}))})});
    const data = await r.json();
    if(!r.ok) throw new Error(data.error||'Could not create session');
    sendSession = {sessionId:data.sessionId, code:data.code, uploadToken:data.uploadToken, status:'uploading'};
    $('#sendSession').classList.remove('hidden');
    $('#sendCode').textContent = data.code;
    $('#sendExpiry').textContent = 'Expires ' + new Date(data.expiresAt).toLocaleTimeString();
    loadShare(data.sessionId, data.uploadToken);
    saveActive({sessionId:data.sessionId, direction:'Sent', device:deviceName(), status:'Uploading…', files:sendFiles.map(f=>f.name).join(', '), total:sendFiles.reduce((a,f)=>a+f.size,0)});
    toast('Code created — uploading now');
    await uploadAll();
  }catch(e){ toast(networkError(e)); sendSession=null; updateSendUI(); }
};
async function loadShare(sessionId, uploadToken){
  const qr = $('#sendQr'), bc = $('#sendBarcode');
  qr.src = `/api/sessions/${sessionId}/qr?token=${uploadToken}`;
  qr.classList.remove('hidden');
  bc.src = `/api/sessions/${sessionId}/barcode?token=${uploadToken}`;
  bc.classList.remove('hidden');
  try{
    const r = await fetch(`/api/sessions/${sessionId}/qr?token=${uploadToken}&format=json`);
    if (r.ok) {
      const d = await r.json();
      $('#sendQrUrl').textContent = d.url.includes('localhost')
        ? `QR link (same device only): ${d.url} — for a phone, open the LAN link on the Home page instead.`
        : `QR link: ${d.url}`;
    }
  }catch{}
}
$('#retrySendBtn').onclick = ()=>{ $('#retrySendBtn').classList.add('hidden'); uploadAll(); };
$('#copyCodeBtn').onclick = async ()=>{ try{ await navigator.clipboard.writeText($('#sendCode').textContent); toast('Code copied'); }catch{ toast('Code: '+$('#sendCode').textContent); } };
$('#cancelSendBtn').onclick = async ()=>{
  sendCancelled = true;
  if(sendSession){
    try{ await fetch('/api/sessions/'+sendSession.sessionId, {method:'DELETE', headers:{'x-upload-token':sendSession.uploadToken}}); }catch{}
    saveHistory({direction:'Sent', device:deviceName(), status:'Cancelled', files:sendFiles.map(f=>f.name).join(', '), total:sendFiles.reduce((a,f)=>a+f.size,0)});
  }
  clearInterval(pollTimer); $('#sendStatus').textContent='Transfer cancelled'; toast('Transfer cancelled and server files deleted');
  if(sendSession) sendSession.status='cancelled';
  updateSendUI();
};

// ---------- RECEIVE ----------
function codeValue(){ return $$('#digits input').map(i=>i.value).join(''); }
$$('#digits input').forEach((input, idx)=>{
  input.addEventListener('input', ()=>{ input.value = input.value.replace(/\D/g,'').slice(0,1); if(input.value && idx<5) $('#digits input')[idx+1].focus(); });
  input.addEventListener('keydown', e=>{ if(e.key==='Backspace' && !input.value && idx>0) $('#digits input')[idx-1].focus(); });
  input.addEventListener('paste', e=>{ e.preventDefault(); const d=(e.clipboardData.getData('text')||'').replace(/\D/g,'').slice(0,6); d.split('').forEach((ch,i)=>{ if($('#digits input')[i]) $('#digits input')[i].value=ch; }); if(d.length===6) $('#digits input')[5].focus(); });
});
$('#clearCodeBtn').onclick = ()=>{ $$('#digits input').forEach(i=>i.value=''); $('#digits input')[0].focus(); $('#incoming').classList.add('hidden'); };
let incoming = null;
$('#verifyBtn').onclick = async ()=>{
  const code = codeValue();
  if(!/^\d{6}$/.test(code)){ $('#receiveMsg').textContent='Enter all 6 digits.'; return; }
  setBusy($('#verifyBtn'), true, 'Verifying…');
  $('#receiveMsg').textContent='Verifying…';
  try{
    const r = await fetch('/api/sessions/verify', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({code})});
    const data = await r.json();
    if(!r.ok) throw new Error(data.error||'Verification failed');
    incoming = {...data, code};
    $('#incoming').classList.remove('hidden');
    $('#fromDevice').textContent = data.deviceName;
    $('#incomingExpiry').textContent = new Date(data.expiresAt).toLocaleTimeString();
    $('#incomingStatus').textContent = data.status + (data.status!=='ready' ? ` — upload ${data.progress}% complete` : ' — ready to accept');
    $('#incomingList').innerHTML = data.files.map(f=>`<div class="file-item"><span aria-hidden="true">📄</span><div class="meta"><b>${esc(f.name)}</b><span class="muted small">${esc(f.type)} · ${fmt(f.size)} · ${f.complete?'ready':'uploading '+fmt(f.receivedBytes)}</span></div></div>`).join('');
    $('#incomingTotal').textContent = `${data.files.length} file(s) · Total ${fmt(data.totalSize)}`;
    $('#acceptBtn').disabled = data.status!=='ready';
    $('#receiveMsg').textContent = data.status==='ready' ? 'Check the files above, then Accept to download.' : 'The sender is still uploading. Wait a moment, then Verify again.';
    saveActive({sessionId:data.sessionId, direction:'Received', device:data.deviceName, status:'Awaiting accept', files:data.files.map(f=>f.name).join(', '), total:data.totalSize});
  }catch(e){ $('#receiveMsg').textContent = networkError(e); }
  finally{ setBusy($('#verifyBtn'), false); }
};
// ---------- QR / barcode scanning ----------
// A scanned value is NEVER trusted as proof: it only fills the 6-digit
// boxes (or the ?code= link). The user must still press Verify, and the
// server must still validate the code and expiry before Accept works.
function fillCode(code){
  if (!/^\d{6}$/.test(code)) return false;
  $$('#digits input').forEach((input, i)=>{ input.value = code[i] || ''; });
  return true;
}
function codeFromScanned(text){
  const t = String(text || '').trim();
  if (/^\d{6}$/.test(t)) return t;
  try { const u = new URL(t); const c = u.searchParams.get('code'); if (c && /^\d{6}$/.test(c)) return c; } catch {}
  const m = t.match(/\b\d{6}\b/);
  return m ? m[0] : null;
}
let scanStream = null, scanTimer = null;
function stopScan(){
  if (scanTimer) { clearInterval(scanTimer); scanTimer = null; }
  if (scanStream) { scanStream.getTracks().forEach(tr => tr.stop()); scanStream = null; }
  const v = $('#scanVideo'); v.classList.add('hidden'); v.srcObject = null;
  $('#stopScanBtn').classList.add('hidden');
  $('#scanBtn').disabled = false;
}
$('#stopScanBtn').onclick = stopScan;
$('#scanBtn').onclick = async ()=>{
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    $('#scanMsg').textContent = 'This browser cannot use the camera. Enter the code by hand, or open the QR link with your phone camera app.';
    return;
  }
  if (!('BarcodeDetector' in window)) {
    $('#scanMsg').textContent = 'This browser has no built-in BarcodeDetector (it works in Chrome on Android). Use your phone camera app to scan the QR code instead — it opens Receive with the code filled in.';
    return;
  }
  try{
    $('#scanBtn').disabled = true;
    scanStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
    const v = $('#scanVideo'); v.srcObject = scanStream; v.classList.remove('hidden'); await v.play();
    $('#stopScanBtn').classList.remove('hidden');
    $('#scanMsg').textContent = 'Point the camera at the QR code or barcode…';
    const detector = new BarcodeDetector({ formats: ['qr_code', 'code_128', 'code_39', 'ean_13'] });
    scanTimer = setInterval(async ()=>{
      try{
        const results = await detector.detect(v);
        if (!results || !results.length) return;
        const code = codeFromScanned(results[0].rawValue);
        if (!code) { $('#scanMsg').textContent = 'Scanned, but that is not a valid 6-digit transfer code.'; return; }
        fillCode(code); stopScan();
        $('#scanMsg').textContent = 'Code filled in from scan — press Verify to check it.';
        toast('Code filled in from scan');
      }catch{}
    }, 300);
  }catch(e){
    $('#scanMsg').textContent = 'Camera permission was denied or is unavailable. Enter the code by hand instead.';
    stopScan();
  }
};
$('#rejectBtn').onclick = async ()=>{
  if(!incoming) return;
  try{ await fetch(`/api/sessions/${incoming.sessionId}/reject`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({code:incoming.code})}); }catch{}
  saveHistory({direction:'Received', device:incoming.deviceName, status:'Rejected', files:incoming.files.map(f=>f.name).join(', '), total:incoming.totalSize});
  $('#incoming').classList.add('hidden'); toast('Transfer rejected');
};
async function downloadOne(file, index, onProgress){
  const url = `/api/sessions/${incoming.sessionId}/files/${index}?token=${incoming.acceptToken}`;
  if(file.size > 500*1024*1024){
    // Avoid holding a huge file in memory: let the browser download it directly.
    const a = document.createElement('a'); a.href=url; a.download=file.name; document.body.appendChild(a); a.click(); a.remove(); onProgress?.(file.size); return;
  }
  const r = await fetch(url); if(!r.ok) throw new Error('Download failed ('+r.status+')');
  const reader = r.body.getReader(); const chunks=[]; let got=0; const t0=performance.now();
  while(true){ const {done,value}=await reader.read(); if(done) break; chunks.push(value); got+=value.length; const el=(performance.now()-t0)/1000; onProgress?.(got, el>0?got/el:0); }
  const blob = new Blob(chunks, {type:file.type});
  const a = document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=file.name; document.body.appendChild(a); a.click();
  setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); }, 2000);
}
$('#acceptBtn').onclick = async ()=>{
  if(!incoming) return;
  setBusy($('#acceptBtn'), true, 'Accepting…');
  try{
    const r = await fetch(`/api/sessions/${incoming.sessionId}/accept`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({code:incoming.code})});
    const data = await r.json(); if(!r.ok) throw new Error(data.error||'Could not accept');
    incoming.acceptToken = data.acceptToken;
    $('#downloadArea').classList.remove('hidden'); $('#acceptBtn').disabled=true; $('#rejectBtn').disabled=true;
    toast('Accepted — press Download all, or download a file below');
    // Add per-file download buttons
    $('#incomingList').innerHTML = incoming.files.map((f,i)=>`<div class="file-item"><span aria-hidden="true">📄</span><div class="meta"><b>${esc(f.name)}</b><span class="muted small">${fmt(f.size)}</span></div><button class="btn ghost" data-dl="${i}">Download</button></div>`).join('');
    $$('#incomingList [data-dl]').forEach(b=>b.onclick=async()=>{ try{ await downloadOne(incoming.files[+b.dataset.dl], +b.dataset.dl, ()=>{}); toast('Downloaded '+incoming.files[+b.dataset.dl].name); }catch(e){ toast(networkError(e)); } });
  }catch(e){ toast(networkError(e)); setBusy($('#acceptBtn'), false); }
};
$('#downloadAllBtn').onclick = async ()=>{
  if(!incoming?.acceptToken) return;
  const total = incoming.totalSize; let doneBytes=0; const t0=performance.now();
  try{
    for(let i=0;i<incoming.files.length;i++){
      const f=incoming.files[i];
      await downloadOne(f, i, (got, speed)=>{
        const overall = doneBytes+got, pct=Math.round(overall/total*100);
        $('#dlBar').style.width=pct+'%'; $('#dlPct').textContent=pct+'%'; $('#dlSpeed').textContent=fmtSpeed(speed);
        const el=(performance.now()-t0)/1000, avg=el>0?overall/el:0; $('#dlEta').textContent = avg>0?fmtEta((total-overall)/avg):'—';
      });
      doneBytes += f.size;
    }
    $('#dlBar').style.width='100%'; $('#dlPct').textContent='100%';
    saveHistory({direction:'Received', device:incoming.deviceName, status:'Completed', files:incoming.files.map(f=>f.name).join(', '), total});
    toast('All files downloaded ✓');
  }catch(e){ toast(networkError(e)); }
};

// ---------- ACTIVE / HISTORY ----------
function renderActive(){
  const a = JSON.parse(localStorage.getItem('nova_active')||'[]');
  $('#activeList').innerHTML = a.length ? a.map(x=>`<div class="card glass"><b>${esc(x.direction)} · ${esc(x.status)}</b><p class="muted small">${esc(x.device||'')} · ${esc(x.files||'')} · ${x.total?fmt(x.total):''}</p></div>`).join('') : '<p class="muted">No active transfers on this device yet.</p>';
}
function renderHistory(){
  const h = JSON.parse(localStorage.getItem('nova_history')||'[]');
  $('#historyList').innerHTML = h.length ? h.map(x=>`<div class="card glass"><b>${esc(x.direction)} · ${esc(x.status)}</b><p class="muted small">${new Date(x.time).toLocaleString()} · ${esc(x.device||'')} · ${esc(x.files||'')} · ${x.total?fmt(x.total):''}</p></div>`).join('') : '<p class="muted">No history yet.</p>';
}
$('#clearHistoryBtn').onclick = ()=>{ localStorage.removeItem('nova_history'); renderHistory(); toast('Local history cleared'); };

// ---------- init ----------
$('#sendDevice').value = localStorage.getItem('nova_device')||'';
$('#settingDevice').value = localStorage.getItem('nova_device')||'';
$('#reduceMotion').checked = localStorage.getItem('nova_reduce')==='1';
applyTheme(); loadConfig(); renderActive(); renderHistory(); startParticles();
// FIX: a QR link (?code=123456&view=receive) must actually land on Receive
// with the code filled in. Previously query params were ignored entirely.
try{
  const params = new URLSearchParams(location.search);
  const qCode = params.get('code');
  if (qCode && /^\d{6}$/.test(qCode)) {
    fillCode(qCode);
    show('receive');
    $('#receiveMsg').textContent = 'Code filled in from the QR link — press Verify to check it.';
  } else if (params.get('view') === 'receive') {
    show('receive');
  }
}catch{}
