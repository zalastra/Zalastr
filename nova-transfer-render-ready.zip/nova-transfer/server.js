/**
 * NOVA TRANSFER — backend
 * -----------------------
 * Real, server-relayed file transfer (not a simulation):
 *   Sender uploads files in 1 MiB chunks -> server stores them temporarily
 *   -> receiver verifies a 6-digit code -> explicitly accepts
 *   -> receiver downloads the exact bytes the sender uploaded.
 *
 * Why server relay instead of pure WebRTC?
 * Phones / PCs behind mobile NATs and corporate firewalls often cannot
 * establish a direct peer connection at all. A relay works on every
 * browser, on every network, and is the honest default. WebRTC could be
 * layered on top later as an optimisation; it must never be presented
 * as a transfer that did not happen.
 *
 * Security model (enforced here, not just in the UI):
 *  - A 6-digit code is ONLY a lookup key for one explicitly-created
 *    session. It grants no device access, no browsing, no silent transfer.
 *  - Files are only those the sender explicitly selected and uploaded.
 *  - A receiver sees metadata only, and downloads only after Accept.
 *  - Codes / sessions expire automatically (TRANSFER_TTL_MINUTES).
 *  - Verify attempts are rate-limited per IP and per code.
 *  - Filenames are sanitised (no path traversal), sizes are capped
 *    server-side, files live outside the public web root and are deleted
 *    on expiry / cancel / completion-cleanup.
 *  - No passwords, banking PINs or OTPs are ever requested or stored.
 *
 * Run:  npm install && npm start   (http://localhost:3000)
 * Env:  see .env.example
 */
import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import os from 'os';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { WebSocketServer } from 'ws';
import QRCode from 'qrcode';
import bwipjs from 'bwip-js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ---------- minimal .env loader (no dependency) ----------
// FIX A1: .env.example existed but nothing ever read .env, so user
// settings in .env were silently ignored. Values already present in the
// real environment win over .env, so production env vars are not overridden.
try {
  const envPath = path.join(__dirname, '.env');
  if (fs.existsSync(envPath)) {
    for (const rawLine of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
      const line = rawLine.trim();
      if (!line || line.startsWith('#')) continue;
      const eq = line.indexOf('=');
      if (eq <= 0) continue;
      const key = line.slice(0, eq).trim();
      let value = line.slice(eq + 1).trim();
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      if (!(key in process.env)) process.env[key] = value;
    }
  }
} catch { /* .env is optional; missing/unreadable file must not stop startup */ }

// ---------- config ----------
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0'; // FIX A2: explicit LAN binding, see listen() below
const TRUST_PROXY = process.env.TRUST_PROXY === 'true';
const TTL_MS = Number(process.env.TRANSFER_TTL_MINUTES || 15) * 60 * 1000;
const MAX_FILE_BYTES = Number(process.env.MAX_FILE_SIZE_MB || 2048) * 1024 * 1024;
const MAX_TOTAL_BYTES = Number(process.env.MAX_TOTAL_SIZE_MB || 5120) * 1024 * 1024;
const MAX_FILES = 50;
const CHUNK_LIMIT = 2 * 1024 * 1024; // client sends 1 MiB chunks
const MAX_VERIFY_ATTEMPTS_PER_IP = 20; // per 10 minutes
const MAX_WRONG_CODES_PER_IP = 10; // per 10 minutes, then 429
const MAX_SESSIONS_PER_IP = 30; // per 10 minutes, session creation only
// FIX A9: a relative STORAGE_DIR is resolved against the project folder,
// not the caller's cwd — running from C:\Users\Kishan with a full path to
// server.js previously scattered storage into the cwd.
const STORAGE_DIR = process.env.STORAGE_DIR ? path.resolve(__dirname, process.env.STORAGE_DIR) : path.join(__dirname, 'storage');
const PUBLIC_DIR = path.join(__dirname, 'public');

fs.mkdirSync(STORAGE_DIR, { recursive: true });

const app = express();
app.set('trust proxy', TRUST_PROXY);
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

// ---------- in-memory state (single-instance; see README for Redis/R2 scale-out) ----------
/** @type {Map<string, any>} */
const sessions = new Map();
/** @type {Map<string, {count:number, resetAt:number, wrong:number}>} */
const ipVerify = new Map();
/** @type {Map<string, {count:number, resetAt:number}>} */
const ipCreate = new Map();

function now() { return Date.now(); }
function lanAddresses() {
  const out = [];
  for (const addrs of Object.values(os.networkInterfaces())) {
    for (const a of addrs || []) {
      if (a.family === 'IPv4' && !a.internal) out.push(a.address);
    }
  }
  return out;
}
function isLocalHost(hostname) {
  return hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1' || hostname === '[::1]';
}
// FIX A3: never build a QR/receive URL that points at localhost when the
// recipient is on another device. If the request host is localhost, swap
// it for the server's first LAN address; otherwise keep the request host.
function receiveUrl(req, session) {
  const rawHost = (req.get('host') || `localhost:${PORT}`).trim();
  const hostname = rawHost.split(':')[0].replace(/^\[|\]$/g, '');
  let host = rawHost;
  if (isLocalHost(hostname)) {
    const lan = lanAddresses()[0];
    if (lan) host = `${lan}:${PORT}`;
  }
  const proto = TRUST_PROXY && req.get('x-forwarded-proto') ? req.get('x-forwarded-proto').split(',')[0].trim() : (req.socket.encrypted ? 'https' : 'http');
  return `${proto}://${host}/?code=${session.code}&view=receive`;
}
function randomCode() { return String(crypto.randomInt(100000, 1000000)); }
function randomToken() { return crypto.randomBytes(32).toString('hex'); }
function sanitiseName(name) {
  const base = path.basename(String(name || 'file')).replace(/[\\/:*?"<>|]/g, '_');
  return (base || 'file').slice(0, 200);
}
function isExpired(s) { return now() > s.expiresAt || s.status === 'expired'; }

function publicFile(f) {
  return { name: f.name, size: f.size, type: f.type, complete: f.complete, receivedBytes: f.receivedBytes, sha256: f.sha256 || null };
}
function publicSession(s) {
  const received = s.files.reduce((a, f) => a + f.receivedBytes, 0);
  return {
    sessionId: s.id, deviceName: s.deviceName, status: s.status,
    expiresAt: s.expiresAt, createdAt: s.createdAt,
    files: s.files.map(publicFile), totalSize: s.totalSize, receivedBytes: received,
    progress: s.totalSize ? Math.round((received / s.totalSize) * 100) : 0,
    accepted: s.status === 'accepted' || s.status === 'downloading' || s.status === 'completed',
  };
}
function broadcast(s, payload) {
  const msg = JSON.stringify({ type: 'status', session: publicSession(s), ...payload });
  for (const ws of s.clients) { try { if (ws.readyState === 1) ws.send(msg); } catch {} }
}
function deleteSessionFiles(s) {
  try { fs.rmSync(s.dir, { recursive: true, force: true }); } catch {}
}
function expireSession(s, status = 'expired') {
  if (s.status === 'cancelled' || s.status === 'completed') return;
  s.status = status;
  broadcast(s, {});
  deleteSessionFiles(s);
  // Keep the metadata tombstone briefly so polling clients see the final state.
  setTimeout(() => { sessions.delete(s.id); }, 5000);
}

// ---------- middleware ----------
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  // FIX A4: camera=(self) is required for QR/barcode scanning; the old
  // camera=() header would have blocked getUserMedia outright.
  // Microphone/geolocation stay blocked — this app never needs them.
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' blob: data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self' ws: wss:; font-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'");
  next();
});
app.use(express.json({ limit: '256kb' }));
app.use(express.static(PUBLIC_DIR, { maxAge: '1h' }));

function clientIp(req) {
  // FIX A6: X-Forwarded-For is only trusted behind a real proxy
  // (TRUST_PROXY=true). Otherwise anyone could spoof it and bypass
  // the verify rate limit.
  if (TRUST_PROXY) {
    const fwd = req.headers['x-forwarded-for']?.toString().split(',')[0]?.trim();
    if (fwd) return fwd;
  }
  return (req.socket.remoteAddress || 'unknown').trim();
}

// ---------- public config (so the UI can show real limits, not invent them) ----------
app.get('/api/config', (req, res) => {
  res.json({
    ttlMinutes: TTL_MS / 60000,
    maxFileMB: MAX_FILE_BYTES / 1024 / 1024,
    maxTotalMB: MAX_TOTAL_BYTES / 1024 / 1024,
    maxFiles: MAX_FILES,
    chunkBytes: 1024 * 1024,
    lanUrls: lanAddresses().map(ip => `http://${ip}:${PORT}`),
  });
});
app.get('/api/health', (req, res) => res.json({ ok: true, activeSessions: sessions.size }));

// ---------- QR / barcode (sender only, token-gated) ----------
// The QR encodes ONLY the 6-digit code in a receive URL — never a token.
// Scanning it does not verify or download anything: the receiver must
// still press Verify, then Accept. A QR that merely contains a code is
// never trusted as proof on its own.
function shareSession(req, res) {
  const s = sessions.get(req.params.id);
  if (!s) return { status: 404, error: 'Session not found.' };
  if (isExpired(s)) { expireSession(s); return { status: 410, error: 'This transfer code has expired.' }; }
  if (req.query.token !== s.uploadToken) return { status: 403, error: 'Not authorised for this session.' };
  return { session: s };
}
app.get('/api/sessions/:id/qr', async (req, res) => {
  const r = shareSession(req, res);
  if (r.error) return res.status(r.status).json({ error: r.error });
  const url = receiveUrl(req, r.session);
  if (req.query.format === 'json') return res.json({ url, code: r.session.code, sessionId: r.session.id, expiresAt: r.session.expiresAt });
  try {
    const png = await QRCode.toBuffer(url, { type: 'png', width: 320, margin: 2, errorCorrectionLevel: 'M' });
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Cache-Control', 'no-store');
    res.send(png);
  } catch { res.status(500).json({ error: 'Could not generate QR code.' }); }
});
app.get('/api/sessions/:id/barcode', async (req, res) => {
  const r = shareSession(req, res);
  if (r.error) return res.status(r.status).json({ error: r.error });
  if (req.query.format === 'json') return res.json({ code: r.session.code, sessionId: r.session.id, expiresAt: r.session.expiresAt });
  try {
    const png = await bwipjs.toBuffer({ bcid: 'code128', text: r.session.code, scale: 3, height: 12, includetext: true, backgroundcolor: 'FFFFFF' });
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Cache-Control', 'no-store');
    res.send(png);
  } catch { res.status(500).json({ error: 'Could not generate barcode.' }); }
});

// ---------- create session (sender) ----------
app.post('/api/sessions', (req, res) => {
  const ip = clientIp(req);
  const rec = ipCreate.get(ip) || { count: 0, resetAt: now() + 10 * 60 * 1000 };
  if (now() > rec.resetAt) { rec.count = 0; rec.resetAt = now() + 10 * 60 * 1000; }
  rec.count++;
  ipCreate.set(ip, rec);
  if (rec.count > MAX_SESSIONS_PER_IP) return res.status(429).json({ error: 'Too many transfers started. Please wait a few minutes.' });
  const { deviceName, files } = req.body || {};
  if (!Array.isArray(files) || files.length === 0 || files.length > MAX_FILES) {
    return res.status(400).json({ error: `Select between 1 and ${MAX_FILES} files.` });
  }
  let total = 0;
  for (const f of files) {
    if (!f || typeof f.name !== 'string' || !Number.isFinite(f.size) || f.size <= 0) {
      return res.status(400).json({ error: 'Each file needs a valid name and size.' });
    }
    if (f.size > MAX_FILE_BYTES) {
      return res.status(413).json({ error: `File "${f.name}" exceeds the server limit of ${MAX_FILE_BYTES / 1024 / 1024} MB.` });
    }
    total += f.size;
  }
  if (total > MAX_TOTAL_BYTES) {
    return res.status(413).json({ error: `Total size exceeds the server limit of ${MAX_TOTAL_BYTES / 1024 / 1024} MB.` });
  }
  // Unique code among active sessions.
  let code = randomCode();
  let guard = 0;
  while ([...sessions.values()].some(s => s.code === code && !isExpired(s)) && guard++ < 50) code = randomCode();

  const id = randomToken().slice(0, 24);
  const dir = path.join(STORAGE_DIR, id);
  fs.mkdirSync(dir, { recursive: true });
  const session = {
    id, code, deviceName: String(deviceName || 'Unknown device').slice(0, 80) || 'Unknown device',
    createdAt: now(), expiresAt: now() + TTL_MS, status: 'uploading',
    uploadToken: randomToken(), acceptToken: null,
    files: files.map((f, i) => ({
      index: i, name: sanitiseName(f.name), size: f.size,
      type: String(f.type || 'application/octet-stream').slice(0, 120),
      receivedBytes: 0, totalChunks: Math.ceil(f.size / (1024 * 1024)),
      receivedChunks: new Set(), complete: false, sha256: null,
      // FIX A5: hash is updated per chunk, never by re-reading the whole
      // file into memory on completion.
      hash: crypto.createHash('sha256'),
      tmpPath: path.join(dir, `${i}.part`),
    })),
    totalSize: total, dir, clients: new Set(), downloaded: new Set(),
  };
  sessions.set(id, session);
  res.status(201).json({ sessionId: id, code, expiresAt: session.expiresAt, uploadToken: session.uploadToken, totalSize: total });
});

// ---------- chunk upload (sender, resumable, sequential per file) ----------
app.post('/api/sessions/:id/chunks',
  express.raw({ type: '*/*', limit: CHUNK_LIMIT }),
  (req, res) => {
    const s = sessions.get(req.params.id);
    if (!s || isExpired(s)) return res.status(404).json({ error: 'Session not found or expired.' });
    if (s.status === 'cancelled') return res.status(410).json({ error: 'Transfer was cancelled.' });
    if (req.headers['x-upload-token'] !== s.uploadToken) return res.status(403).json({ error: 'Invalid upload token.' });

    const fileIndex = Number(req.headers['x-file-index']);
    const chunkIndex = Number(req.headers['x-chunk-index']);
    const totalChunks = Number(req.headers['x-total-chunks']);
    const f = s.files[fileIndex];
    if (!f || !Number.isInteger(chunkIndex) || chunkIndex < 0 || totalChunks !== f.totalChunks) {
      return res.status(400).json({ error: 'Invalid chunk metadata.' });
    }
    if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
      return res.status(400).json({ error: 'Empty chunk.' });
    }
    // Idempotent retry: a chunk already received is acknowledged, not re-appended.
    if (!f.receivedChunks.has(chunkIndex)) {
      // Sequential upload is enforced by the client; a gap means a lost chunk.
      if (chunkIndex !== f.receivedChunks.size && !(chunkIndex === 0 && f.receivedChunks.size === 0)) {
        // Allow out-of-order only if the client restarts the file cleanly; otherwise reject.
        if (chunkIndex !== 0) return res.status(409).json({ error: 'Chunk out of order — retry this file from its last confirmed chunk.', receivedBytes: f.receivedBytes });
      }
      fs.appendFileSync(f.tmpPath, req.body);
      f.hash.update(req.body);
      f.receivedChunks.add(chunkIndex);
      f.receivedBytes += req.body.length;
    }
    if (f.receivedBytes > f.size) {
      return res.status(400).json({ error: 'File size mismatch.' });
    }
    if (f.receivedBytes === f.size && chunkIndex === f.totalChunks - 1) {
      f.sha256 = f.hash.digest('hex');
      f.complete = true;
    }
    if (s.files.every(x => x.complete)) {
      s.status = 'ready';
    }
    broadcast(s, {});
    res.json({ receivedBytes: f.receivedBytes, complete: f.complete, sessionStatus: s.status, sha256: f.sha256 });
  }
);

// ---------- session status (sender token, receiver token, or code for metadata only) ----------
app.get('/api/sessions/:id/status', (req, res) => {
  const s = sessions.get(req.params.id);
  if (!s) return res.status(404).json({ error: 'Session not found.' });
  if (isExpired(s)) { expireSession(s); return res.status(410).json({ error: 'This transfer code has expired.' }); }
  const { token, code } = req.query;
  const ok = token === s.uploadToken || token === s.acceptToken || code === s.code;
  if (!ok) return res.status(403).json({ error: 'Not authorised for this session.' });
  res.json(publicSession(s));
});

// ---------- verify code (receiver) — rate limited, generic errors ----------
app.post('/api/sessions/verify', (req, res) => {
  const { code } = req.body || {};
  if (typeof code !== 'string' || !/^\d{6}$/.test(code)) {
    return res.status(400).json({ error: 'Enter a 6-digit code.' });
  }
  const ip = clientIp(req);
  const rec = ipVerify.get(ip) || { count: 0, wrong: 0, resetAt: now() + 10 * 60 * 1000 };
  if (now() > rec.resetAt) { rec.count = 0; rec.wrong = 0; rec.resetAt = now() + 10 * 60 * 1000; }
  rec.count++;
  ipVerify.set(ip, rec);
  if (rec.count > MAX_VERIFY_ATTEMPTS_PER_IP || rec.wrong >= MAX_WRONG_CODES_PER_IP) {
    return res.status(429).json({ error: 'Too many attempts. Please wait 10 minutes and try again.' });
  }
  const s = [...sessions.values()].find(x => x.code === code && !isExpired(x) && x.status !== 'cancelled');
  if (!s) {
    rec.wrong++;
    return res.status(404).json({ error: 'Invalid or expired code. Check the code and try again.' });
  }
  // Metadata only — no download token is issued until Accept.
  res.json(publicSession(s));
});

// ---------- accept / reject (receiver consent) ----------
app.post('/api/sessions/:id/accept', (req, res) => {
  const s = sessions.get(req.params.id);
  if (!s || isExpired(s)) return res.status(404).json({ error: 'Session not found or expired.' });
  if ((req.body || {}).code !== s.code) return res.status(403).json({ error: 'Invalid code.' });
  if (s.status !== 'ready') {
    return res.status(409).json({ error: `Files are not ready yet (upload ${publicSession(s).progress}%). Please wait for the sender to finish uploading.`, ...publicSession(s) });
  }
  s.acceptToken = randomToken();
  s.status = 'accepted';
  broadcast(s, {});
  res.json({ acceptToken: s.acceptToken, ...publicSession(s) });
});
app.post('/api/sessions/:id/reject', (req, res) => {
  const s = sessions.get(req.params.id);
  if (!s) return res.status(404).json({ error: 'Session not found.' });
  if ((req.body || {}).code !== s.code) return res.status(403).json({ error: 'Invalid code.' });
  expireSession(s, 'cancelled');
  res.json({ ok: true });
});

// ---------- download (receiver, only after Accept) ----------
app.get('/api/sessions/:id/files/:index', (req, res) => {
  const s = sessions.get(req.params.id);
  if (!s || isExpired(s)) return res.status(404).json({ error: 'Session not found or expired.' });
  if (req.query.token !== s.acceptToken) return res.status(403).json({ error: 'Accept the transfer first.' });
  const f = s.files[Number(req.params.index)];
  if (!f || !f.complete) return res.status(404).json({ error: 'File not ready.' });
  let stat;
  try { stat = fs.statSync(f.tmpPath); } catch { return res.status(404).json({ error: 'File no longer available (expired or deleted).' }); }
  s.status = 'downloading';
  res.setHeader('Content-Type', f.type);
  res.setHeader('Content-Length', stat.size);
  res.setHeader('Content-Disposition', `attachment; filename="${f.name.replace(/"/g, '')}"`);
  if (f.sha256) res.setHeader('X-File-Sha256', f.sha256);
  const stream = fs.createReadStream(f.tmpPath);
  stream.on('error', () => { try { if (!res.headersSent) res.status(500).json({ error: 'Download failed.' }); else res.destroy(); } catch {} });
  stream.pipe(res);
  stream.on('end', () => {
    s.downloaded.add(f.index);
    if (s.downloaded.size >= s.files.length) { s.status = 'completed'; broadcast(s, {}); }
  });
});

// ---------- cancel (either side, with its own token) ----------
app.delete('/api/sessions/:id', (req, res) => {
  const s = sessions.get(req.params.id);
  if (!s) return res.status(404).json({ error: 'Session not found.' });
  const token = req.headers['x-upload-token'] || req.headers['x-accept-token'] || (req.body || {}).token;
  if (token !== s.uploadToken && token !== s.acceptToken) return res.status(403).json({ error: 'Not authorised to cancel this transfer.' });
  expireSession(s, 'cancelled');
  res.json({ ok: true });
});

// ---------- WebSocket: live status only, no file bytes over WS ----------
wss.on('connection', (ws, req) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const s = sessions.get(url.searchParams.get('sessionId') || '');
    const token = url.searchParams.get('token') || '';
    if (!s || (token !== s.uploadToken && token !== s.acceptToken && token !== s.code)) { ws.close(4403, 'unauthorised'); return; }
    s.clients.add(ws);
    ws.send(JSON.stringify({ type: 'status', session: publicSession(s) }));
    ws.on('close', () => s.clients.delete(ws));
  } catch { ws.close(1011, 'bad request'); }
});

// ---------- cleanup ----------
setInterval(() => {
  for (const s of [...sessions.values()]) {
    if (now() <= s.expiresAt) continue;
    if (s.status === 'completed') { deleteSessionFiles(s); sessions.delete(s.id); }
    else expireSession(s);
  }
  // FIX: ip rate-limit maps must not grow forever for IPs that never return.
  for (const [ip, rec] of ipVerify) if (now() > rec.resetAt) ipVerify.delete(ip);
  for (const [ip, rec] of ipCreate) if (now() > rec.resetAt) ipCreate.delete(ip);
}, 60 * 1000);

// SPA fallback
app.get('*', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));

server.listen(PORT, HOST, () => {
  console.log(`NOVA TRANSFER running on http://localhost:${PORT}`);
  for (const ip of lanAddresses()) console.log(`  On your Wi-Fi / hotspot, open: http://${ip}:${PORT}`);
  console.log(`  TTL: ${TTL_MS / 60000} min | max file: ${MAX_FILE_BYTES / 1024 / 1024} MB | max total: ${MAX_TOTAL_BYTES / 1024 / 1024} MB`);
  console.log('  Storage is temporary and deleted on expiry / cancel. Use HTTPS (reverse proxy) in production.');
});
