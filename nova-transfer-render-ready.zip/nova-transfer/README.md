# ✦ NOVA TRANSFER

A complete, working universal file-transfer web app — not a visual prototype.

**The flow:** Open the site → Select files → Generate a 6-digit code → Enter the code on another device → Accept → Download.

Works between Android ↔ Windows, phone ↔ phone, PC ↔ PC, tablet ↔ PC, and any other device with a modern browser. No sign-up, no install, no app store.

## What was built

| Area | Implementation |
|---|---|
| Frontend | Vanilla HTML/CSS/JS in `public/` — no build step, so it runs on budget Android phones and old PCs. Dark + light themes, glassmorphism, particle background (pauses when hidden / reduced-motion), progress ring, 6-box code entry with auto-advance + paste, drag-and-drop, image previews. |
| Backend | Node.js + Express (`server.js`), WebSocket live status (`/ws`) with 3-second polling fallback. |
| Transfer | Real server relay: files upload in 1 MB chunks, are stored temporarily on disk, and are streamed back on download. Chunk retries (×3) + resume from the last confirmed chunk. SHA-256 is computed server-side on completion and returned in metadata / the `X-File-Sha256` download header. |
| Sessions | Unique 6-digit code per session, separate sender `uploadToken` and receiver `acceptToken`. A code alone downloads nothing. |
| Security | See below. |

## Quick start

```bash
cd nova-transfer
npm install
npm start
# open http://localhost:3000
```

Test it with two browser windows (or a phone + PC on the same network — use your machine's LAN IP instead of `localhost` on the phone):

```bash
# terminal 1: npm start
# terminal 2: npm test     # full sender→receiver flow, byte-for-byte check
```

Configuration: copy `.env.example` to `.env` (or set environment variables). The server now actually reads `.env` on startup. Defaults: 15-minute code expiry, 2 GB per file, 5 GB per transfer, 50 files, bind `0.0.0.0` (reachable on LAN).

## QR code, barcode, and phone access (the "network error" fix)

Previous version had **no QR/barcode code at all**, and gave the phone no reachable address — so users tried `localhost` on the phone, or the hotspot gateway IP, and got a network error.

Now, after you press **Generate Transfer Code**:

- A **QR code** and a **Code128 barcode** for the same 6-digit code appear under the code.
- The QR encodes a receive URL, e.g. `http://192.168.x.x:3000/?code=123456&view=receive`. If you opened the sender page on `localhost`, the server swaps `localhost` for its LAN address, so the QR never points a phone at its own localhost.
- Scanning the QR **only fills in the code**. The receiver must still press **Verify**, then **Accept** — a scanned code is never trusted as proof on its own.
- On the Receive page, **Scan QR / Barcode** uses the camera (Chrome on Android, via `BarcodeDetector`). If your browser has no `BarcodeDetector`, or camera permission is denied, it says so plainly and tells you to type the code or open the QR link with your phone camera app. Camera tracks are stopped when you press Stop scanning or a code is found.
- The Home page also lists the LAN URLs from `/api/config` (e.g. `http://192.168.x.x:3000`) — open one of those on the phone, not `localhost`, and not the gateway address.

If you still see a network error, it means the browser cannot reach the server at all: check the server CMD is still running, the hotspot/Wi-Fi is still connected, and the phone address matches the PC's *current* `ipconfig` IPv4 address (hotspot IPs change on reconnect).

## Windows and Termux

- **Windows CMD:** always run from the project folder, e.g. `cd /d %USERPROFILE%\Downloads\nova-transfer`, then `npm install` and `npm start`. A second folder with the same name (e.g. `C:\Users\Kishan\nova-transfer` vs `Downloads\nova-transfer`) is the most common cause of `ENOENT: package.json` — check the prompt shows `Downloads\nova-transfer`.
- **Termux (Android):** install Node.js (`pkg install nodejs`), then the same `npm install` / `npm start` in the project folder. No global install is needed. The phone running the server is then the server; other devices open its LAN IP, not `localhost` on their own device.
- Relative `STORAGE_DIR` in `.env` is resolved against the project folder, not the CMD working directory.

## Security model — read this before deploying

- **A code is not device access.** It is a lookup key for one session containing only the files the sender explicitly selected and uploaded. It cannot browse storage, photos, contacts or apps, and it cannot control a device.
- **Two consents are required:** the sender chooses + uploads the files, and the receiver sees names/sizes first and must press **Accept** before any download token is issued.
- **Expiry + cleanup:** sessions expire after `TRANSFER_TTL_MINUTES` (default 15). Expired and cancelled sessions have their files deleted from disk. Completed sessions are deleted at expiry too.
- **Brute-force protection:** verify attempts are rate-limited per IP (20 attempts / 10 min, max 10 wrong codes / 10 min → HTTP 429). Errors are generic ("Invalid or expired code") so an attacker learns nothing.
- **Validation:** filenames are sanitised (`basename`, dangerous characters stripped) so no path traversal; file/total sizes are enforced server-side, not just in the UI; chunk metadata is validated; upload/download tokens are 256-bit random values.
- **No sensitive data is ever requested:** the app never asks for passwords, banking PINs or financial OTPs. Treat anyone asking for those "for a transfer" as a scam.
- **History privacy:** the History tab stores only names, sizes, direction and timestamps in the browser's local storage. File contents are never stored there.

## Production deployment

1. **Use HTTPS.** Put the app behind a reverse proxy (Caddy, nginx, or a platform like Render/Railway/Fly.io) with TLS. The app itself serves plain HTTP on `PORT` for local use.
2. Set `STORAGE_DIR` to a disk with enough space, and size `MAX_FILE_SIZE_MB` / `MAX_TOTAL_SIZE_MB` to match it.
3. **Scale-out note:** sessions currently live in memory with files on local disk (correct for one server). For multiple servers, move session state to Redis and storage to S3-compatible object storage (e.g. Cloudflare R2 — store under `sessions/<id>/<index>`, with the same expiry/cleanup lifecycle) and keep the same API contract.
4. Consider adding, in front of the app, your platform's rate limiting / WAF and an upload antivirus scan if you accept files from untrusted senders — receivers should still only open files from senders they trust, as with email attachments.

## Architecture & API

```
Sender ── POST /api/sessions ──────────────► code + uploadToken
Sender ── POST /api/sessions/:id/chunks ───► 1 MB chunks, idempotent retry
Receiver ─ POST /api/sessions/verify ──────► metadata only (no download)
Receiver ─ POST /api/sessions/:id/accept ──► acceptToken (only when status=ready)
Receiver ─ GET  /api/sessions/:id/files/:i?token=acceptToken ──► streamed download
Either ─── DELETE /api/sessions/:id (with own token) ──► files deleted
Live ───── GET  /api/sessions/:id/status?token=…  +  WS /ws?sessionId=…&token=…
Public ─── GET  /api/config, GET /api/health
```

Why a server relay instead of direct WebRTC? Direct peer connections frequently fail across mobile NATs, hotspots and corporate firewalls, and would silently fail for exactly the users this is for. The relay works on every browser and network. WebRTC could later be added as an optional fast path, but it must never be reported as a transfer that did not complete.

## Browser / platform notes (shown in the app too)

- Downloads go to the browser's normal download folder. On iOS, large downloads land in Files.
- Browsers may ask permission to download multiple files — allow it once for the site.
- For files over 500 MB the frontend uses the browser's own download (anchor) instead of buffering the file in memory; progress for those files is shown by the browser, not the ring.
- Chunk size is 1 MB, which keeps memory low on slow / mobile connections.

## Project structure

```
nova-transfer/
  server.js            # Express + WebSocket backend, sessions, chunk upload, cleanup
  public/
    index.html         # Home / Send / Receive / Active / History / Settings
    styles.css         # Dark/light themes, glassmorphism, animations
    app.js             # Chunked upload, code entry, streaming download, history
  test-flow.mjs        # End-to-end test (create → upload → verify → accept → download → byte check → cancel)
  package.json  .env.example  .gitignore  README.md
```

## Deployment: local vs LAN vs public — do not confuse them

1. **Working locally:** `http://localhost:3000` on the same PC only.
2. **Working on the same Wi-Fi / hotspot:** `http://<PC LAN IP>:3000` on the phone, with the server bound to `0.0.0.0` (the default). The server prints these LAN URLs on startup.
3. **Accessible through a public internet URL:** NOT achieved by this local setup. That needs a host (Render/Railway/Fly.io/VPS) + a domain + HTTPS via a reverse proxy, with `TRUST_PROXY=true` only behind that trusted proxy, and storage moved off local disk if you scale past one server.
4. **Persistent cloud storage:** NOT configured by default. Files are temporary local-disk storage and are deleted on expiry/cancel. Cloudflare R2 / S3 would be a separate integration (see scale-out note above), not a claim made here.

## Limitations, stated honestly

- This is a single-server reference implementation. It is not end-to-end encrypted: the server temporarily holds the files (as any relay must) — for highly sensitive files, encrypt them yourself (e.g. a password-protected ZIP) before sending.
- The in-memory session store is lost on server restart; in-flight uploads would need to be restarted.
- No user accounts, so "History" is per-browser only.


## Hosting warning

**Do not deploy this Node.js project directly as a Cloudflare Worker or as static-only Cloudflare Pages.** It requires a Node.js server, WebSocket endpoint, filesystem APIs and temporary storage. For the simplest free test deployment, follow [DEPLOY-RENDER.md](DEPLOY-RENDER.md). Free hosting has sleep and temporary-storage limitations.
