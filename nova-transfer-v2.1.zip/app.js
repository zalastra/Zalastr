// NOVA TRANSFER v2.1 - FIXED static, direct device-to-device via PeerJS + WebRTC.
// Fixes for v2.0 transfer failures:
// 1. Chunk size 64KB -> 16KB. Large messages were overflowing the DataChannel buffer.
// 2. Backpressure was checking conn.bufferSize, which PeerJS does not expose.
//    Now it checks the real RTCDataChannel bufferedAmount and pauses.
// 3. Receiver now accepts ArrayBuffer, Blob and Uint8Array chunks.
// 4. A file is offered for download ONLY when received bytes == file size,
//    not just when a file-end message arrives. This stops corrupt / failed PDFs.
// 5. Images get a preview, videos get a playable preview, so "video chal nahi rahi"
//    can be checked right in the browser, plus a Download button for every file.
// No backend API, no /api calls, no server storage. Both devices must stay online.
const $ = (s) => document.querySelector(s);
const fmt = (n) => n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB';
const CHUNK = 16384; // 16KB, the safe WebRTC DataChannel chunk size
const MAX_BUFFERED = 262144; // pause sending above 256KB buffered

function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.remove('hidden');
  setTimeout(() => t.classList.add('hidden'), 4000);
}
function saveHistory(item) {
  try {
    const h = JSON.parse(localStorage.getItem('nova_v2_history') || '[]');
    h.unshift({ time: new Date().toLocaleString(), ...item });
    localStorage.setItem('nova_v2_history', JSON.stringify(h.slice(0, 20)));
    renderHistory();
  } catch {}
}
function renderHistory() {
  try {
    const h = JSON.parse(localStorage.getItem('nova_v2_history') || '[]');
    $('#historyList').innerHTML = h.length ? h.map(x => `<div class="fileitem"><span>${x.direction} · ${x.status}</span><span class="muted small">${x.time} · ${x.files || ''}</span></div>`).join('') : '<p class="muted">No history yet.</p>';
  } catch {}
}
renderHistory();

document.querySelectorAll('.tabbtn').forEach(b => {
  b.onclick = () => {
    document.querySelectorAll('.tabbtn').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    ['send', 'receive', 'how'].forEach(t => $('#tab-' + t).classList.toggle('hidden', t !== b.dataset.tab));
  };
});
function showTab(name) { document.querySelector(`.tabbtn[data-tab="${name}"]`).click(); }

// ---------- SENDER ----------
let sendFiles = [], senderPeer = null, senderConn = null, sending = false;
let pendingAck = null;

const dz = $('#dropzone');
dz.onclick = () => $('#fileInput').click();
['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('dragging'); }));
['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('dragging'); }));
dz.addEventListener('drop', e => addFiles(e.dataTransfer.files));
$('#fileInput').onchange = e => addFiles(e.target.files);

function addFiles(list) { for (const f of list) sendFiles.push(f); renderSendFiles(); }
function renderSendFiles() {
  $('#fileList').innerHTML = sendFiles.map((f, i) => `<div class="fileitem"><span>📄 ${f.name}</span><span class="muted small">${fmt(f.size)} · <a href="#" data-i="${i}" style="color:#f87171">Remove</a></span></div>`).join('');
  document.querySelectorAll('#fileList a').forEach(a => a.onclick = (e) => { e.preventDefault(); sendFiles.splice(Number(a.dataset.i), 1); renderSendFiles(); });
  const total = sendFiles.reduce((a, f) => a + f.size, 0);
  $('#fileTotal').textContent = sendFiles.length ? `${sendFiles.length} file(s) · Total ${fmt(total)}` : '';
  $('#generateBtn').disabled = !sendFiles.length || sending;
}
$('#clearBtn').onclick = () => { sendFiles = []; renderSendFiles(); $('#sendStatus').classList.add('hidden'); try { senderPeer && senderPeer.destroy(); } catch {} senderPeer = null; };

function showCode(code) {
  const box = $('#codeBox'); box.innerHTML = '';
  for (const ch of code) { const s = document.createElement('span'); s.textContent = ch; box.appendChild(s); }
  try {
    if (window.QRCode) {
      const url = location.href.split('?')[0].split('#')[0] + '?code=' + code + '#receive';
      window.QRCode.toCanvas($('#qrCanvas'), url, { width: 180, margin: 1 });
      $('#qrNote').textContent = 'Scan with phone camera to open Receive with this code filled.';
    } else { $('#qrNote').textContent = 'QR needs internet for the QR library. Code above still works by typing it.'; }
  } catch { $('#qrNote').textContent = ''; }
}

function getDataChannel(conn) {
  // PeerJS DataConnection exposes the raw RTCDataChannel as .dataChannel in v1.5.
  return conn && conn.dataChannel ? conn.dataChannel : null;
}
async function waitForBuffer(conn) {
  const dc = getDataChannel(conn);
  if (!dc) { await new Promise(r => setTimeout(r, 10)); return; }
  let waited = 0;
  while (dc.bufferedAmount > MAX_BUFFERED && waited < 30000) {
    await new Promise(r => setTimeout(r, 50));
    waited += 50;
  }
}

$('#generateBtn').onclick = async () => {
  if (!sendFiles.length) return;
  const code = String(Math.floor(100000 + Math.random() * 900000));
  const device = ($('#sendDevice').value || '').trim() || 'My device';
  sending = true; $('#generateBtn').disabled = true;
  $('#sendStatus').classList.remove('hidden');
  $('#senderState').textContent = 'Connecting… please wait, code is being created.';
  showCode(code);
  if (typeof Peer === 'undefined') {
    $('#senderState').textContent = 'PeerJS library did not load. Check internet and reload the page.';
    sending = false; $('#generateBtn').disabled = false; return;
  }
  // Use PeerJS defaults (0.peerjs.com, 443, path /) - do not override them.
  senderPeer = new Peer('nova-' + code);
  senderPeer.on('open', () => { $('#senderState').textContent = 'Code ready. Share it. Waiting for receiver to connect…'; });
  senderPeer.on('error', (err) => {
    const t = err && err.type ? err.type : 'connection error';
    $('#senderState').textContent = 'Connection problem: ' + t + '. Reload and try a new code.';
    if (t === 'unavailable-id') { $('#senderState').textContent = 'This code is already in use. Click Generate again for a new code.'; sending = false; $('#generateBtn').disabled = false; }
  });
  senderPeer.on('connection', (conn) => {
    senderConn = conn;
    conn.on('open', () => { $('#senderState').textContent = 'Receiver connected. Waiting for accept…'; });
    conn.on('error', (e) => { $('#senderState').textContent = 'Connection broke. Keep this page open and ask receiver to reconnect with the same code.'; });
    conn.on('data', async (data) => {
      if (data && data.type === 'hello') {
        conn.send({ type: 'meta', device, files: sendFiles.map(f => ({ name: f.name, size: f.size, type: f.type })) });
        $('#senderState').textContent = 'Receiver saw your files. Waiting for accept…';
      }
      if (data && data.type === 'accept') {
        $('#senderState').textContent = 'Receiver accepted. Sending files…';
        await sendAllFiles(conn);
      }
      if (data && data.type === 'file-received') {
        if (pendingAck) { const r = pendingAck; pendingAck = null; r(); }
      }
    });
    conn.on('close', () => { if (sending) $('#senderState').textContent = 'Receiver disconnected. Keep this page open and ask receiver to reconnect with the same code.'; });
  });
};

function waitForFileAck(timeoutMs) {
  return new Promise((resolve) => {
    pendingAck = resolve;
    setTimeout(() => { if (pendingAck) { pendingAck = null; resolve(); } }, timeoutMs);
  });
}

async function sendAllFiles(conn) {
  const total = sendFiles.reduce((a, f) => a + f.size, 0);
  let sent = 0;
  try {
    for (let fi = 0; fi < sendFiles.length; fi++) {
      const f = sendFiles[fi];
      conn.send({ type: 'file-start', index: fi, name: f.name, size: f.size, fileType: f.type });
      await new Promise(r => setTimeout(r, 50));
      for (let off = 0; off < f.size; off += CHUNK) {
        const slice = f.slice(off, Math.min(off + CHUNK, f.size));
        const buf = await slice.arrayBuffer();
        await waitForBuffer(conn);
        conn.send(buf);
        sent += buf.byteLength;
        const pct = total ? Math.round(sent / total * 100) : 100;
        $('#sendProgress').style.width = pct + '%';
        $('#sendProgressText').textContent = `Sent ${fmt(sent)} of ${fmt(total)} · ${pct}% · File ${fi + 1} of ${sendFiles.length}`;
        // Let the browser flush the channel between chunks.
        await new Promise(r => setTimeout(r, 0));
      }
      conn.send({ type: 'file-end', index: fi });
      // Wait until receiver confirms it actually got all bytes for this file.
      await waitForFileAck(30000);
      $('#senderState').textContent = `File ${fi + 1} of ${sendFiles.length} delivered. Sending next…`;
    }
    conn.send({ type: 'done' });
    $('#senderState').textContent = 'Transfer complete ✓';
    $('#sendProgress').style.width = '100%';
    toast('Transfer complete ✓');
    saveHistory({ direction: 'Sent', status: 'Completed', files: sendFiles.map(f => f.name).join(', ') });
    sending = false;
  } catch (e) {
    $('#senderState').textContent = 'Transfer failed. Receiver may have closed the page. Try again with a new code.';
    sending = false; $('#generateBtn').disabled = false;
  }
}
$('#cancelSendBtn').onclick = () => {
  try { senderConn && senderConn.close(); senderPeer && senderPeer.destroy(); } catch {}
  sending = false; $('#senderState').textContent = 'Transfer cancelled.'; $('#generateBtn').disabled = !sendFiles.length;
};

// ---------- RECEIVER ----------
let recvPeer = null, recvConn = null;
let recvMeta = null, recvFiles = {}, recvTotal = 0, recvGot = 0, currentFileIndex = -1;

function setRecvState(t) { $('#recvState').textContent = t; }
function offerFileDownload(f) {
  const blob = new Blob(f.chunks, { type: f.fileType || 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const wrap = document.createElement('div');
  wrap.className = 'fileitem';
  wrap.style.display = 'block';
  let preview = '';
  if ((f.fileType || '').startsWith('image/')) preview = `<br><img src="${url}" style="max-width:100%;border-radius:10px;margin-top:8px" alt="${f.name}">`;
  else if ((f.fileType || '').startsWith('video/')) preview = `<br><video controls src="${url}" style="max-width:100%;border-radius:10px;margin-top:8px"></video>`;
  else if (f.fileType === 'application/pdf') preview = `<br><a href="${url}" target="_blank" rel="noopener" style="color:#22d3ee">Open PDF in new tab</a>`;
  wrap.innerHTML = `<b>✓ ${f.name}</b> · ${fmt(f.size)} · Complete${preview}<br><a href="${url}" download="${f.name}" class="btn primary" style="display:inline-block;margin-top:10px;text-decoration:none">⬇ Download ${f.name}</a>`;
  $('#downloadList').appendChild(wrap);
}
function checkFileComplete(index) {
  const f = recvFiles[index]; if (!f || f.offered) return;
  const got = f.chunks.reduce((a, c) => a + c.byteLength, 0);
  if (got >= f.size) {
    f.offered = true;
    offerFileDownload(f);
    if (recvConn) { try { recvConn.send({ type: 'file-received', index }); } catch {} }
  }
}

$('#verifyBtn').onclick = () => {
  const code = ($('#recvCode').value || '').trim();
  if (!/^\d{6}$/.test(code)) { setRecvState('Please enter a valid 6-digit code.'); return; }
  if (typeof Peer === 'undefined') { setRecvState('PeerJS library did not load. Check internet and reload.'); return; }
  setRecvState('Connecting to sender…');
  recvPeer = new Peer();
  recvPeer.on('open', () => {
    recvConn = recvPeer.connect('nova-' + code, { reliable: true });
    recvConn.on('open', () => {
      setRecvState('Connected. Asking sender for file list…');
      recvConn.send({ type: 'hello', device: ($('#recvDevice').value || '').trim() || 'Receiver device' });
    });
    recvConn.on('error', () => setRecvState('Connection broke. Ask sender to keep their page open and try again.'));
    recvConn.on('data', onRecvData);
    recvConn.on('close', () => setRecvState('Sender disconnected. Ask sender to keep their page open and connect again.'));
  });
  recvPeer.on('error', (err) => {
    if (err && err.type === 'peer-unavailable') setRecvState('Code not found or sender is not online. Check the code and make sure the sender page is still open.');
    else setRecvState('Connection problem: ' + (err && err.type ? err.type : 'could not connect. Try again.'));
  });
};

async function onRecvData(data) {
  if (data && data.type === 'meta') {
    recvMeta = data; recvTotal = data.files.reduce((a, f) => a + f.size, 0); recvGot = 0; recvFiles = {}; currentFileIndex = -1;
    $('#incomingList').innerHTML = data.files.map((f) => `<div class="fileitem"><span>📄 ${f.name}</span><span class="muted small">${fmt(f.size)}</span></div>`).join('');
    setRecvState(`From ${data.device || 'sender'} · ${data.files.length} file(s) · Total ${fmt(recvTotal)}. Check the list, then Accept.`);
    $('#acceptBtn').classList.remove('hidden');
    return;
  }
  if (data && data.type === 'file-start') {
    currentFileIndex = data.index;
    recvFiles[data.index] = { name: data.name, size: data.size, fileType: data.fileType, chunks: [], offered: false };
    return;
  }
  if (data && data.type === 'file-end') {
    // Do not trust file-end alone. Only offer when bytes are complete.
    checkFileComplete(data.index);
    return;
  }
  if (data && data.type === 'done') {
    setRecvState('Transfer complete ✓ Click Download for each file above. If a file is missing, it did not finish — ask sender to resend with a new code.');
    toast('Transfer complete ✓');
    saveHistory({ direction: 'Received', status: 'Completed', files: recvMeta ? recvMeta.files.map(f => f.name).join(', ') : '' });
    return;
  }
  // Binary chunk: ArrayBuffer, Blob, or Uint8Array — all handled.
  let buf = null;
  if (data instanceof ArrayBuffer) buf = data;
  else if (data instanceof Blob) buf = await data.arrayBuffer();
  else if (data instanceof Uint8Array) buf = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
  else if (data && data.byteLength !== undefined) buf = data;
  if (!buf) return;
  if (currentFileIndex < 0) return;
  const cur = recvFiles[currentFileIndex]; if (!cur) return;
  cur.chunks.push(buf); recvGot += buf.byteLength;
  const pct = recvTotal ? Math.round(recvGot / recvTotal * 100) : 100;
  $('#recvProgressWrap').classList.remove('hidden');
  $('#recvProgress').style.width = pct + '%';
  $('#recvProgressText').textContent = `Received ${fmt(recvGot)} of ${fmt(recvTotal)} · ${pct}%`;
  checkFileComplete(currentFileIndex);
}
$('#acceptBtn').onclick = () => {
  if (!recvConn) return;
  recvConn.send({ type: 'accept' });
  setRecvState('Accepted. Downloading… keep this page open.');
  $('#acceptBtn').classList.add('hidden');
};

try {
  const params = new URLSearchParams(location.search);
  const c = params.get('code');
  if (c && /^\d{6}$/.test(c)) { $('#recvCode').value = c; showTab('receive'); setRecvState('Code filled from QR/link. Click Connect.'); }
} catch {}
