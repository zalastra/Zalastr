// NOVA TRANSFER v2 - static, direct device-to-device via PeerJS + WebRTC.
// No backend API, no /api calls, no server storage. Both devices must stay online.
const $ = (s) => document.querySelector(s);
const fmt = (n) => n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB';
const CHUNK = 65536;

function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.remove('hidden');
  setTimeout(() => t.classList.add('hidden'), 4000);
}
function saveHistory(item) {
  try {
    const h = JSON.parse(localStorage.getItem('nova_v2_history') || '[]');
    h.unshift({ time: new Date().toLocaleString(), ...item });
    localStorage.setItem('nova_v2_history', JSON.stringify(h.slice(0, 20)));
    renderHistory();
  } catch {}
}
function renderHistory() {
  try {
    const h = JSON.parse(localStorage.getItem('nova_v2_history') || '[]');
    $('#historyList').innerHTML = h.length ? h.map(x => `<div class="fileitem"><span>${x.direction} · ${x.status}</span><span class="muted small">${x.time} · ${x.files || ''}</span></div>`).join('') : '<p class="muted">No history yet.</p>';
  } catch {}
}
renderHistory();

// Tabs
document.querySelectorAll('.tabbtn').forEach(b => {
  b.onclick = () => {
    document.querySelectorAll('.tabbtn').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    ['send', 'receive', 'how'].forEach(t => $('#tab-' + t).classList.toggle('hidden', t !== b.dataset.tab));
  };
});
function showTab(name) {
  document.querySelector(`.tabbtn[data-tab="${name}"]`).click();
}

// ---------- SENDER ----------
let sendFiles = [], senderPeer = null, senderConn = null, sending = false;

const dz = $('#dropzone');
dz.onclick = () => $('#fileInput').click();
['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('dragging'); }));
['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('dragging'); }));
dz.addEventListener('drop', e => addFiles(e.dataTransfer.files));
$('#fileInput').onchange = e => addFiles(e.target.files);

function addFiles(list) {
  for (const f of list) sendFiles.push(f);
  renderSendFiles();
}
function renderSendFiles() {
  $('#fileList').innerHTML = sendFiles.map((f, i) => `<div class="fileitem"><span>📄 ${f.name}</span><span class="muted small">${fmt(f.size)} · <a href="#" data-i="${i}" style="color:#f87171">Remove</a></span></div>`).join('');
  document.querySelectorAll('#fileList a').forEach(a => a.onclick = (e) => { e.preventDefault(); sendFiles.splice(Number(a.dataset.i), 1); renderSendFiles(); });
  const total = sendFiles.reduce((a, f) => a + f.size, 0);
  $('#fileTotal').textContent = sendFiles.length ? `${sendFiles.length} file(s) · Total ${fmt(total)}` : '';
  $('#generateBtn').disabled = !sendFiles.length || sending;
}
$('#clearBtn').onclick = () => { sendFiles = []; renderSendFiles(); $('#sendStatus').classList.add('hidden'); try { senderPeer && senderPeer.destroy(); } catch {} senderPeer = null; };

function showCode(code) {
  const box = $('#codeBox'); box.innerHTML = '';
  for (const ch of code) { const s = document.createElement('span'); s.textContent = ch; box.appendChild(s); }
  // QR encodes this same site + code, so scanning opens Receive with code filled.
  try {
    if (window.QRCode) {
      const url = location.href.split('?')[0].split('#')[0] + '?code=' + code + '#receive';
      window.QRCode.toCanvas($('#qrCanvas'), url, { width: 180, margin: 1 });
      $('#qrNote').textContent = 'Scan with phone camera to open Receive with this code filled.';
    } else { $('#qrNote').textContent = 'QR needs internet for the QR library. Code above still works by typing it.'; }
  } catch { $('#qrNote').textContent = ''; }
}

$('#generateBtn').onclick = async () => {
  if (!sendFiles.length) return;
  const code = String(Math.floor(100000 + Math.random() * 900000));
  const device = ($('#sendDevice').value || '').trim() || 'My device';
  sending = true; $('#generateBtn').disabled = true;
  $('#sendStatus').classList.remove('hidden');
  $('#senderState').textContent = 'Connecting… please wait, code is being created.';
  showCode(code);

  if (typeof Peer === 'undefined') {
    $('#senderState').textContent = 'PeerJS library did not load. Check internet and reload the page.';
    sending = false; $('#generateBtn').disabled = false; return;
  }
  senderPeer = new Peer('nova-' + code, { host: '0.peerjs.com', port: 443, path: '/', secure: true });
  senderPeer.on('open', () => { $('#senderState').textContent = 'Code ready. Share it. Waiting for receiver to connect…'; });
  senderPeer.on('error', (err) => {
    $('#senderState').textContent = 'Connection problem: ' + (err && err.type ? err.type : 'could not connect to signalling. Reload and try again.');
    if (err && err.type === 'unavailable-id') { $('#senderState').textContent = 'This code is already in use. Click Generate again for a new code.'; sending = false; $('#generateBtn').disabled = false; }
  });
  senderPeer.on('connection', (conn) => {
    senderConn = conn;
    conn.on('open', () => { $('#senderState').textContent = 'Receiver connected. Waiting for accept…'; });
    conn.on('data', async (data) => {
      if (data && data.type === 'hello') {
        conn.send({ type: 'meta', device, files: sendFiles.map(f => ({ name: f.name, size: f.size, type: f.type })) });
        $('#senderState').textContent = 'Receiver saw your files. Waiting for accept…';
      }
      if (data && data.type === 'accept') {
        $('#senderState').textContent = 'Receiver accepted. Sending files…';
        await sendAllFiles(conn);
      }
    });
    conn.on('close', () => { if (sending) $('#senderState').textContent = 'Receiver disconnected. Keep this page open and ask receiver to reconnect with the same code.'; });
  });
};

async function waitForBuffer(conn) {
  while (conn.bufferSize > 1024 * 1024) { await new Promise(r => setTimeout(r, 50)); }
}
async function sendAllFiles(conn) {
  const total = sendFiles.reduce((a, f) => a + f.size, 0);
  let sent = 0;
  try {
    for (let fi = 0; fi < sendFiles.length; fi++) {
      const f = sendFiles[fi];
      conn.send({ type: 'file-start', index: fi, name: f.name, size: f.size, fileType: f.type });
      await waitForBuffer(conn);
      for (let off = 0; off < f.size; off += CHUNK) {
        const slice = f.slice(off, Math.min(off + CHUNK, f.size));
        const buf = await slice.arrayBuffer();
        conn.send(buf);
        sent += buf.byteLength;
        const pct = total ? Math.round(sent / total * 100) : 100;
        $('#sendProgress').style.width = pct + '%';
        $('#sendProgressText').textContent = `Sent ${fmt(sent)} of ${fmt(total)} · ${pct}%`;
        await waitForBuffer(conn);
      }
      conn.send({ type: 'file-end', index: fi });
    }
    conn.send({ type: 'done' });
    $('#senderState').textContent = 'Transfer complete ✓';
    $('#sendProgress').style.width = '100%';
    toast('Transfer complete ✓');
    saveHistory({ direction: 'Sent', status: 'Completed', files: sendFiles.map(f => f.name).join(', ') });
    sending = false;
  } catch (e) {
    $('#senderState').textContent = 'Transfer failed. Receiver may have closed the page. Try again with a new code.';
    sending = false; $('#generateBtn').disabled = false;
  }
}
$('#cancelSendBtn').onclick = () => {
  try { senderConn && senderConn.close(); senderPeer && senderPeer.destroy(); } catch {}
  sending = false; $('#senderState').textContent = 'Transfer cancelled.'; $('#generateBtn').disabled = !sendFiles.length;
};

// ---------- RECEIVER ----------
let recvPeer = null, recvConn = null;
let recvMeta = null, recvFiles = {}, recvTotal = 0, recvGot = 0;

function setRecvState(t) { $('#recvState').textContent = t; }

$('#verifyBtn').onclick = () => {
  const code = ($('#recvCode').value || '').trim();
  if (!/^\d{6}$/.test(code)) { setRecvState('Please enter a valid 6-digit code.'); return; }
  if (typeof Peer === 'undefined') { setRecvState('PeerJS library did not load. Check internet and reload.'); return; }
  setRecvState('Connecting to sender…');
  recvPeer = new Peer({ host: '0.peerjs.com', port: 443, path: '/', secure: true });
  recvPeer.on('open', () => {
    recvConn = recvPeer.connect('nova-' + code, { reliable: true });
    recvConn.on('open', () => {
      setRecvState('Connected. Asking sender for file list…');
      recvConn.send({ type: 'hello', device: ($('#recvDevice').value || '').trim() || 'Receiver device' });
    });
    recvConn.on('data', onRecvData);
    recvConn.on('close', () => setRecvState('Sender disconnected. Ask sender to keep their page open and connect again.'));
  });
  recvPeer.on('error', (err) => {
    if (err && err.type === 'peer-unavailable') setRecvState('Code not found or sender is not online. Check the code and make sure the sender page is still open.');
    else setRecvState('Connection problem: ' + (err && err.type ? err.type : 'could not connect. Try again.'));
  });
};

function onRecvData(data) {
  if (data && data.type === 'meta') {
    recvMeta = data; recvTotal = data.files.reduce((a, f) => a + f.size, 0); recvGot = 0; recvFiles = {};
    $('#incomingList').innerHTML = data.files.map((f, i) => `<div class="fileitem"><span>📄 ${f.name}</span><span class="muted small">${fmt(f.size)}</span></div>`).join('');
    setRecvState(`From ${data.device || 'sender'} · ${data.files.length} file(s) · Total ${fmt(recvTotal)}. Check the list, then Accept.`);
    $('#acceptBtn').classList.remove('hidden');
    return;
  }
  if (data && data.type === 'file-start') {
    recvFiles[data.index] = { name: data.name, size: data.size, fileType: data.fileType, chunks: [] };
    return;
  }
  if (data instanceof ArrayBuffer) {
    // Find the latest open file (sender sends files in order, one at a time).
    const keys = Object.keys(recvFiles);
    if (!keys.length) return;
    const cur = recvFiles[keys[keys.length - 1]];
    cur.chunks.push(data); recvGot += data.byteLength;
    const pct = recvTotal ? Math.round(recvGot / recvTotal * 100) : 100;
    $('#recvProgressWrap').classList.remove('hidden');
    $('#recvProgress').style.width = pct + '%';
    $('#recvProgressText').textContent = `Received ${fmt(recvGot)} of ${fmt(recvTotal)} · ${pct}%`;
    return;
  }
  if (data && data.type === 'file-end') {
    const f = recvFiles[data.index]; if (!f) return;
    const blob = new Blob(f.chunks, { type: f.fileType || 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = f.name; a.textContent = '⬇ Download ' + f.name;
    a.className = 'btn primary'; a.style.display = 'inline-block'; a.style.margin = '6px 6px 0 0'; a.style.textDecoration = 'none';
    $('#downloadList').appendChild(a);
    return;
  }
  if (data && data.type === 'done') {
    setRecvState('Transfer complete ✓ Click Download for each file above.');
    toast('Transfer complete ✓');
    saveHistory({ direction: 'Received', status: 'Completed', files: recvMeta ? recvMeta.files.map(f => f.name).join(', ') : '' });
  }
}
$('#acceptBtn').onclick = () => {
  if (!recvConn) return;
  recvConn.send({ type: 'accept' });
  setRecvState('Accepted. Downloading… keep this page open.');
  $('#acceptBtn').classList.add('hidden');
};

// Auto-fill code from URL ?code=123456
try {
  const params = new URLSearchParams(location.search);
  const c = params.get('code');
  if (c && /^\d{6}$/.test(c)) { $('#recvCode').value = c; showTab('receive'); setRecvState('Code filled from QR/link. Click Connect.'); }
} catch {}
