# NOVA TRANSFER v2 — Cloudflare par upload karke chalane ke steps

Ye v2 static website hai. Isme koi Node server nahi hai, koi /api nahi hai, koi database nahi hai.
Isliye sirf ye files upload karne se website chal jayegi. Purani v1 ko Workers par isliye nahi chalaya ja sakta tha, kyunki usko Node server chahiye tha.

## Files jo upload karni hain
- index.html
- styles.css
- app.js
- README-DEPLOY.md (ye file upload karna zaroori nahi hai, lekin rakh sakte ho)

In files ko ek folder me rakho, naam kuch bhi ho, jaise nova-transfer-v2.

## Cloudflare Pages se deploy, ek ek karke
1. Cloudflare Dashboard kholo.
2. Workers & Pages par jao.
3. Pages par jao.
4. Create application par click karo.
5. Pages par click karo.
6. Upload assets par click karo.
7. Project ka naam do, jaise nova-transfer-v2.
8. Folder select karo, jisme index.html, styles.css aur app.js hain.
9. Deploy site par click karo.
10. Deploy hone ke baad jo link milega, usko kholo.
11. Send tab me file select karo.
12. Generate Transfer Code par click karo.
13. Jo 6-digit code mile, usko dusre device par Receive me dalo.
14. Dusre device par Accept dabao, phir Download dabao.

## Zaroori baat, ye limit hai, isko chhupana nahi hai
- Dono device ek saath online hone chahiye.
- Sender ka page transfer khatam hone tak khula rehna chahiye. Sender page band karega to transfer ruk jayega.
- Files server par save nahi hoti hain, sidha ek device se dusre device par jati hain.
- Internet chahiye, kyunki code milane ke liye PeerJS signalling use hota hai. File ka data direct jata hai, server par save nahi hota.
- Agar code galat ho ya sender online na ho, to receiver ko "Code not found" dikhega. Tab code dobara check karo aur sender page khula rakho.

## Local test, bina Cloudflare ke
1. Is folder me ek simple server chalao, ya file ko browser me kholo.
2. Do alag browser tab ya do device par site kholo.
3. Ek par Send, dusre par Receive karo, code dalo, Accept karo.

## Purani v1 se farq
- v1: Node + Express + WebSocket + /api + server storage. Localhost par chalti thi, Workers par nahi.
- v2: Static HTML + CSS + JavaScript + WebRTC (PeerJS). Cloudflare Pages, GitHub Pages, Netlify jaise static host par chalti hai.
- v1 ki file is folder me nahi hai, wo alag folder ~/workspace/nova-transfer/ me safe hai.
